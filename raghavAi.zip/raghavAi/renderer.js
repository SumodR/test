const { ipcRenderer } = require('electron')
const startBtn = document.getElementById('startBtn')
const stopBtn = document.getElementById('stopBtn')
const conversation = document.getElementById('conversation')
const statusBar = document.getElementById('status')

let wsConnected = false

// Handle WebSocket connection status
ipcRenderer.on('ws-status', (_, connected) => {
    wsConnected = connected
    statusBar.textContent = `Status: ${connected ? 'Connected' : 'Connecting...'}`
})

// Handle incoming messages
ipcRenderer.on('message', (_, data) => {
    alert("Received data:", data); // Log the raw data received
    alert("Data type:", typeof data); // Log the type of data received
    // Handle both string (legacy) and object messages

    const message = typeof data === 'string' ? {type: 'message', text: data} : data;
    switch(message.type) {
        case 'message':
            // Parse Name: response format
            
            if(message.text==="previewwebcam.jpg"){
                showImage("C:/Users/USER/Documents/prjt/webcam.jpg");
            }
            else if(message.text==="previewscreenshot.jpg"){
                showImage("C:/Users/USER/Documents/prjt/screenshot.jpg");
                
                addMessage(typeof data,data);
            }
            else if (message.text.includes(': ')) {
                const [sender, text] = message.text.split(': ')
                addMessage(sender.trim(), text.trim())
            } 
            else {
                // Fallback for legacy messages
                addMessage(message.sender || 'APP', message.text)
            }
            break

        case 'status':
            statusBar.textContent = `Status: ${message.text}`
            break
        case 'image':
            showImage(message.data||message.path);
            
            break;
    }
})

// Button click handlers
startBtn.addEventListener('click', () => {
    if (wsConnected) {
        ipcRenderer.send('control', 'start')
        startBtn.disabled = true
        stopBtn.disabled = false
    }
})

stopBtn.addEventListener('click', () => {
    ipcRenderer.send('control', 'stop')
    startBtn.disabled = false
    stopBtn.disabled = true
})

function addMessage(sender, text) {
    const div = document.createElement('div')
    
    // Ensure sender is a string and get clean version for class/display
    const senderStr = String(sender || 'App').toLowerCase()  // For CSS class
    const displayName = String(sender || 'App').toUpperCase() // For display
    
    div.className = `message ${senderStr}`  // Lowercase for CSS
    div.innerHTML = `
        <strong>${displayName}:</strong> ${text}
    `
    conversation.appendChild(div)
    conversation.scrollTop = conversation.scrollHeight
}


//image display

function showImage(imageData) {
    const container = document.createElement('div');
    container.className = 'image-message-container';
    
    const img = document.createElement('img');
    img.src = imageData;  // Directly use the data URL
    img.className = 'image-message';
    
    container.appendChild(img);
    conversation.appendChild(container);
    conversation.scrollTop = conversation.scrollHeight;
}