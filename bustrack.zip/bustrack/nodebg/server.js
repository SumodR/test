// server.js
import http from 'http';
import express from 'express';
import { Server } from 'socket.io';
import cors from 'cors';
import bodyParser from 'body-parser';
import sqlite3 from 'sqlite3';
import bcrypt from 'bcrypt';
import path from 'path';


import session from 'express-session';
import SQLiteStore from 'connect-sqlite3'; // Use SQLite for session storage




const app = express();
const server = http.createServer(app);
const io =new Server(server);

// Middleware
app.use(cors());
app.use(bodyParser.json());

app.use(express.static('./'));    //serve static files from public dir.

// Session setup
const SQLiteStoreSession = SQLiteStore(session);
app.use(session({
    store: new SQLiteStoreSession({
        db: 'sessions.db',
        dir: './',
        ttl: 86400 // 1 day in seconds
    }),
    secret: 'your_secret_key', // Change to a secure key
    resave: false,
    saveUninitialized: true,
}));


// Database setup
const db = new sqlite3.Database("C:/Users/Adith/Documents/bus_track/nodebg/busdb.db");

// Start server
const PORT = process.env.PORT || 4001;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});

app.get('/register',(req,res)=>{
    res.sendFile("C:/Users/Adith/Documents/bus_track/nodebg/test.html");
});


    // ====  User Registration  ====
app.post('/register', (req, res) => {
    const { name, username, password, role, profile_info } = req.body;
    const nname = 'newnames' ;
    const hashedPassword = password; // Replace with actual hashing (e.g., bcrypt)
    
    console.log(`Values received: ${JSON.stringify({ name, username, role, profile_info })}`);
    db.run(`INSERT INTO users (name, email,password, role, profile) VALUES (?, ?, ?, ?, ?)`, 
        [nname, name, hashedPassword, role, profile_info], 
        function(err) {
            if (err) {
                console.log(`culdnt Inserted: ${ err.message }`);
                return res.status(400).json({ error: err.message });
            }
            console.log(`Inserted`);
            res.status(201).json({ id: this.lastID });
        });
});


    // ==== User Login  ====
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    console.log(username,password);
    db.get(`SELECT * FROM users WHERE email = ?`, [username], (err, user) => {
        if (err || !user) {
            return res.status(400).json({ error: 'User not found' });
        }

        // Compare hashed password (assuming you store hashed passwords)
        if (user.password !== password) { // Replace with bcrypt.compare
            return res.status(400).json({ error: 'Invalid password' });
        }

        // Store user info in session
        req.session.userId = user.id;
        req.session.username = user.email;
        // Save the user role in the session
        req.session.user = { user:user.email, role: user.role };

        res.status(200).json({ message: 'Login successful', user , role: user.role });
    });

    
});


    // ==== User Logout  ====
app.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).json({ error: 'Failed to log out' });
        }
        res.json({ message: 'Logged out successfully' });
    });
});

// Check Session Status
app.get('/status', (req, res) => {
    if (req.session.userId) {
        res.json({ loggedIn: true, username: req.session.username });
    } else {
        res.json({ loggedIn: false });
    }
});


    // ======   Socket.IO connection    ======
io.on('connection', (socket) => {
    console.log('A user connected',socket.id);

    /*socket.on('authenticate',(data) => {
        const { username, password } = data;    //data received from app..

        db.get(`SELECT * FROM users WHERE email = ?`, [username], (err, user) => {
            if (err || !user) {
                return res.status(400).json({ error: 'User not found' });
            }
        // Check password (should be hashed in real applications)
        if (user.password === password) {
            // Successfully authenticated
            socket.request.session.user = { username, role: user.role };  // Store role in session
            socket.emit('loginSuccess', { role: user.role });
          } else {
            // Password mismatch
            socket.emit('loginFailed', { message: 'Invalid credentials' });
          }
    })

    // Event to check if user is logged in (session-based)
  socket.on('checkSession', () => {
    if (socket.request.session.user) {
      // If user is logged in and session exists, send the role
      socket.emit('loginSuccess', { role: socket.request.session.user.role });
    } else {
      socket.emit('loginFailed', { message: 'User not logged in' });
    }
  });

  // Optional logout event
  socket.on('logout', () => {
    socket.request.session.destroy((err) => {
      if (err) {
        socket.emit('logoutFailed', { message: 'Logout failed' });
      } else {
        socket.emit('loggedOut', { message: 'Logged out successfully' });
      }
    });
  });
});*/
    // Middleware to check user role for specific events
    function checkRole(requiredRole) {
        return (socket, next) => {
            if (socket.request.session.user && socket.request.session.user.role === requiredRole) {
                return next();
            } else {
                return socket.emit('accessDenied', { message: 'You do not have permission to access this feature' });
            }
        };
    }












    socket.on('driverLocation',checkRole('driver'), (data) => {
        const { driver_id, latitude, longitude } = data;

        db.run(`INSERT INTO driver_locations (driver_id, latitude, longitude) VALUES (?, ?, ?)`, 
            [driver_id, latitude, longitude], 
            function(err) {
                if (err) {
                    console.error(err.message);
                }
                // Broadcast to all connected clients
                io.emit('updateLocation', { driver_id, latitude, longitude });
            });
    });


    socket.on('demoGetLoc', (data) => {
        console.log('Received location:', data);
        io.emit('changeLocation',data);
      })


    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});
