//const express = require('express');
//const http = require('http');
//const socketIo = new Server('socket.io');
    //belowRModernMthdsofImporting..theAbove...
    import express from 'express';
    import http from 'http';
    import { Server } from 'socket.io';
    
    
    
    const PORT = process.env.PORT || 4000;
    
    const app = express();    //object for express (expressApp)

    app.use(express.static('./'));
    
    const server = http.createServer(app);      //createsServer..
    const io = new Server(server);                //setup Socketio in server...
    //or;;  const io = socketIO(server);
    
    
    //ListensForCnnctions....performs events inside it...
    io.on('connection', (socket) => {
    
      console.log(`Client connected ${socket.id}`);
    
      socket.on('sendLocation', (data) => {
        console.log('Received location:', data); // Log the received location.
        io.emit('changeLocation', data); // Send that location to everyone connected,client listening for this event..
      });

    // // //error causing disconnect:-
      socket.on('disconnect', () => {
        console.log(`Client disconnected ${socket.id}`);
      });
      
      
    
      socket.on('demoGetLoc', (data) => {
        console.log('Received location:', data);
        io.emit('changeLocation',data);
      })
    });
    
    server.listen(PORT, () => console.log(`Listening on port ${PORT}`));