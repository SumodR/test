import 'package:flutter/material.dart';

import 'package:http/http.dart' as http;
import 'package:bus_track/signin.dart';

import 'package:bus_track/driver_map.dart';

class StudentPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Student Page')),
      body: Column(
        children: [
          Center(
            child: Text('Welcome Student'),
          ),
          ElevatedButton(
              onPressed: () async {
                // Implement logout functionality
                final response = await http.post(
                  Uri.parse('http://localhost:4001/logout'),
                );

                if (response.statusCode == 200) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Logged out successfully')),
                  );
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (context) => LoginScreen(),
                  ));
                }
              },
              child: Text('Logout'),
            ),

            ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => MapTrackingScreen(),
                ));
              }, 
              child: Text('Map'),
              )
        ],
      ),
    );
  }
}
