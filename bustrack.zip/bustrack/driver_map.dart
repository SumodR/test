import 'package:flutter/material.dart';
//import 'package:location/location.dart';
import 'package:geolocator/geolocator.dart';
import 'package:socket_io_client/socket_io_client.dart' as IO;
import 'dart:async';

import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';


class DriverMap extends StatefulWidget {
  const DriverMap({super.key});

  @override
  State<DriverMap> createState() => _DriverMapState();
}

class _DriverMapState extends State<DriverMap> {
  late IO.Socket socket;
  String pos = '';

  void initSocket() {
    socket = IO.io('http://localhost:4001', <String, dynamic>{
      'transports': ['websocket'],
      'autoConnect': true,
    }); 

    //socket.connect();
    socket.onConnect((_){print('Socket Connected...');});
    //socket.disconnect();
    socket.onDisconnect((_){print('Socket Disconnected...');});
    
  } //createsocket_Close

//initAssoonasWidgetisBuilt...
  @override
  void initState() {
    super.initState();
    initSocket();

    //getLocationUpdates();
  } //initState_close
  @override
  void dispose() {
    // Clean up resources
    socket.disconnect(); // Cancel the socket
    super.dispose(); // Call the superclass's dispose method
  }


//HandleLocPerms...
  Future<bool> _handleLocationPermission() async {
    bool serviceEnabled;
    LocationPermission permission;

    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              'Location services are disabled. Please enable the services')));
      return false;
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Location permissions are denied')));
        return false;
      }
    }
    if (permission == LocationPermission.deniedForever) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              'Location permissions are permanently denied, we cannot request permissions.')));
      return false;
    }
    return true;
  }


/*
//---------------------GET--DRIVER--LOCATION--------------------

  bool isStreaming = false;

  Future<void> getLocationUpdates() async {

    if (isStreaming == true) {

      isStreaming = false;

      final hasPermission = await _handleLocationPermission();
      if (!hasPermission) return;

      const locationSettings =
          LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 100);
      
      StreamSubscription<Position> positionStream =
          Geolocator.getPositionStream(locationSettings: locationSettings)
              .listen((Position position) {
        socket.emit('sendLocation', {
          'latitude': position.latitude,
          'longitude': position.longitude,
        });
      });
    }
    else{
      print('Not Streaming rn......');
    }
  }
*/


//---------------------DEMO--DRIVER--LOACTION--------------------
  bool isStreaming = false;

  StreamSubscription<Map<String, double>>? testPosStream;  //listens for Map type's update..

  Future<void> demoLocUpdate() async {

    /*if (isStreaming == false) {
      testPosStream?.cancel();    //stopStreaming...
      print('Stream Stopped..');
      return;
    }*/
    if (isStreaming) {
      print('alredy stremintto..');
      return;
    }

    else{

      final hasPermission = await _handleLocationPermission();
      if (!hasPermission) return;

isStreaming=true;

    //Test-Location-Values...
      List<Map<String, double>> testcoords = [
        {'lat': 9.3150, 'long': 76.6150},
        {'lat': 9.3155, 'long': 76.6155},
        {'lat': 9.3160, 'long': 76.6160},
        {'lat': 9.3165, 'long': 76.6165},
        {'lat': 9.3170, 'long': 76.6170},
        {'lat': 9.3175, 'long': 76.6175},
        {'lat': 9.3180, 'long': 76.6180},
      ];

    //Create a Stream...
      final stream = Stream.periodic(
        const Duration(seconds: 2),
        (count) => testcoords[count % testcoords.length],    //count-to choose whichCordsToSentEchTime..modulus==soafterLenOfListItWrapsAround,LoopBack!!
      );

    //StartStreaming&Listening...
      testPosStream = stream.listen(
        (testcoordVar) {
          print('Latitude: ${testcoordVar['lat']}, Longitude: ${testcoordVar['long']}');
          socket.emit('demoGetLoc', {
          'latitude': testcoordVar['lat'],
          'longitude': testcoordVar['long'],
        });
        },
        onError: (error) {
          print('Error: $error');
        },
        onDone: () {
        isStreaming = false; // !isStreaming;
        print('Stream Done..');
        },
        cancelOnError: true,
      );

      // Optionally, cancel the subscription after some time (e.g., 36 seconds==> moreThan 35= 5*7values..)
      Future.delayed(const Duration(seconds: 36), () {
        testPosStream?.cancel();
        print('Subscription canceled-dueToDelay...');
      });

    }
    
    //Toggle the state for ui-button text change(strt2stp)..
    setState(() {
      //isStreaming = !isStreaming;
    });
  }

/*NotNecessarilyNeeded...*/
  startLocationUpdates(){
    if (!isStreaming ) {
      ////isStreaming = true;
      //getLocationUpdates();
      demoLocUpdate();
      print('ClickedStart..');
    }
    else{
      print('alredy streming..');
    }
    
  }


  stopLocationUpdates(){
    if(isStreaming){
    isStreaming = false;
    //getLocationUpdates();
    //demoLocUpdate();
    testPosStream?.cancel(); 
    print('ClickedStop..');}
    else{
      print('not stremin now..');
    }
  }






  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text('Location Tracking App'),
        ),
        body: Column(
          children: [
            const Center(child: Text("Location Tracking App Body")),

            ElevatedButton(
              onPressed: startLocationUpdates, 
              child: const Text('Start Demo Streaming'),
            ),

            ElevatedButton(
              onPressed: stopLocationUpdates, 
              child: const Text('Stop Streaming'),
            ),

            ElevatedButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => MapTrackingScreen(),
                ));
              },
              child: Text('Don\'t have an account? Register'),
            ),


          ],
        ));
  }
}








class MapTrackingScreen extends StatefulWidget {
  @override
  _MapTrackingScreenState createState() => _MapTrackingScreenState();
}

class _MapTrackingScreenState extends State<MapTrackingScreen> {
  late MapController _mapController;
  late LatLng _trackerLocation;  // This is the tracker's current position.
  bool _isFirstLocation = true;  // Flag to check if it's the first location update.

  late IO.Socket socket;

  @override
  void initState() {
    super.initState();
    _mapController = MapController();
    _trackerLocation = LatLng(0.0, 0.0);  // Default location

    _initializeSocket();
  }

  // Initialize the Socket.IO connection
  void _initializeSocket() {
    // Connect to the server
    socket = IO.io('http://localhost:4001', <String, dynamic>{
      'transports': ['websocket'],  // Use websocket as transport
    });

    // Listen for the 'changeLocation' event and update the tracker location
    socket.on('changeLocation', (data) {
      print('Received location: $data');  // Log the received location

      // Update tracker location with the new data
      setState(() {
        _trackerLocation = LatLng(data['latitude'], data['longitude']);
        
        // If it's the first time, center the map on the tracker location
        if (_isFirstLocation) {
          _mapController.move(_trackerLocation, 15.0);
          _isFirstLocation = false;
        }
      });
    });
  }

  // Recenter the map on the tracker location when the button is pressed
  void _recenterMap() {
    _mapController.move(_trackerLocation, 15.0);  // Move the map to the tracker position
  }

  @override
  void dispose() {
    socket.dispose();  // Close the socket connection when the widget is disposed
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Map Tracking with Socket.IO'),
      ),
      body: Stack(
        children: [
          FlutterMap(
            mapController: _mapController,
            options: MapOptions(
              initialCenter: _trackerLocation,
              initialZoom: 15.0,
              // onPositionChanged: (position, hasGesture) {
              //   // Allow the user to freely pan and zoom the map.
              //   if (!hasGesture) {
              //     setState(() {
              //       _trackerLocation = position.center!;
              //     });
              //   }
              // },
            ),
            children: [
              TileLayer(
                urlTemplate:
                    "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
                subdomains: ['a', 'b', 'c'],
              ),
              MarkerLayer(
                markers: [
                  Marker(
                    point: _trackerLocation,
                    child: Icon(
                      Icons.location_on,
                      color: Colors.blue,
                      size: 40,
                    ),
                  ),
                ],
              ),
            ],
          ),
          Positioned(
            bottom: 30,
            right: 10,
            child: FloatingActionButton(
              onPressed: _recenterMap,
              child: Icon(Icons.my_location),
            ),
          ),
        ],
      ),
    );
  }
}