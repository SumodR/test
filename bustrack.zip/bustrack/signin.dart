import 'dart:convert';

import 'package:flutter/material.dart';
import 'dart:async';
import 'package:http/http.dart' as http;

import 'package:shared_preferences/shared_preferences.dart';


class SignIn extends StatefulWidget {
  const SignIn({super.key});

  @override
  State<SignIn> createState() => _SignInState();
}

class _SignInState extends State<SignIn> {

  final TextEditingController unameController = TextEditingController();
  final TextEditingController pwdController = TextEditingController();

  Future<void> register() async {
    final response = await http.post(
      Uri.parse('http://localhost:4001/register'),
      body: {
        'name': 'akshay',
        'username': unameController.text,
        'password': pwdController.text,
        'role': 'student', // Adjust as needed
        'profile_info': '{}', // Add actual profile info
      },
    );
    
      print('datas sent:'+unameController.text);
    if (response.statusCode == 201) {
      print(response);
      // Handle success
      Navigator.pop(context);
    } else {
      // Handle error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Registration failed')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Register')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: unameController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: pwdController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: register,
              child: Text('Register'),
            ),
          ],
        ),
      ),
    );
  }
}


    //========  LOGIN ========

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController usrnameController = TextEditingController();
  final TextEditingController passwdController = TextEditingController();

  Future<void> login() async {

    final String uname = usrnameController.text;
    final String pwd = passwdController.text;

    final response = await http.post(
      Uri.parse('http://localhost:4001/login'),
      headers: {
        'Content-Type': 'application/json', // Set Content-Type to application/json
      },
      body: jsonEncode({
        'username': uname,
        'password': pwd,
      }),
    );
    print(uname+pwd);

    if (response.statusCode == 200) {
      // Parse the response
      final responseData = json.decode(response.body);

      // Extract role from response
      String role = responseData['role'];

      // Save the role in SharedPreferences
      SharedPreferences prefs = await SharedPreferences.getInstance();
      prefs.setString('role', role);  // Save the user's role



      var userData = jsonDecode(response.body); 
      print('UserData:'+userData.toString());
      // var uname = userData['user']['name']; 
      print('Login sucs: ${response.body}');
      
      // Handle success and navigate to the main app
      // Store the token if using token-based authentication
      // Navigate based on the role
      if (role == 'student') {
        Navigator.pushReplacementNamed(context, '/student');
      } else if (role == 'driver') {
        Navigator.pushReplacementNamed(context, '/driver');
      }

    } else {
      print('Login fail: ${response.body}');
      // Handle error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Login failed')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Login')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: usrnameController,
              decoration: InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: passwdController,
              decoration: InputDecoration(labelText: 'Password'),
              obscureText: true,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: login,
              child: Text('Login'),
            ),
            TextButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => SignIn(),
                ));
              },
              child: Text('Don\'t have an account? Register'),
            ),
          ],
        ),
      ),
    );
  }
}



class LoginSuccessScreen extends StatelessWidget {

  final String username; // Add a variable to hold the username

  // Constructor to receive the username
  LoginSuccessScreen({required this.username});


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Success')),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('Login successful!', style: TextStyle(fontSize: 24)),
            SizedBox(height: 20),
            Text('Welcome, $username!', style: TextStyle(fontSize: 18)), // Display username
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                // Implement logout functionality
                final response = await http.post(
                  Uri.parse('http://localhost:4001/logout'),
                );

                if (response.statusCode == 200) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('Logged out successfully')),
                  );
                  Navigator.of(context).pushReplacement(MaterialPageRoute(
                    builder: (context) => LoginScreen(),
                  ));
                }
              },
              child: Text('Logout'),
            ),
          ],
        ),
      ),
    );
  }
}
