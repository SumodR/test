import 'package:flutter/material.dart';
import 'package:bus_track/signin.dart';
import 'package:bus_track/driver_map.dart';

import 'package:bus_track/student.dart';
import 'package:bus_track/driver.dart';

import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AK-BusTrack',
      theme: ThemeData(
        // This is the theme of your application.
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),
      //home: DriverMap(),

      initialRoute: '/',

      routes: {
        '/': (context) => FutureBuilder<String>(
              future: _getRole(),
              builder: (context, snapshot) {
                if (snapshot.connectionState == ConnectionState.waiting) {
                  return CircularProgressIndicator();
                } else if (snapshot.hasData) {
                  // Navigate based on the saved role
                  if (snapshot.data == 'student') {
                    return StudentPage();
                  } else if (snapshot.data == 'driver') {
                    return DriverPage();
                  }
                }
                // Default to LoginPage if no role found
                return LoginScreen();
              },
            ),
        '/student': (context) => StudentPage(),
        '/driver': (context) => DriverPage(),
      },


    );
  }

    Future<String> _getRole() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return prefs.getString('role') ?? '';  // Return saved role (or empty string if none)
  }


}

