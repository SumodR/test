            <?php
            include('dbconnection.php');
$db=new dbconnection;
              $disaster_type=$_GET["disaster_type"];  
              $sql="select * from tbl_disaster_type where disaster_type_id='$disaster_type'";                
             $res1= $db->execute_query($sql);
  while($row1=mysqli_fetch_array($res1))
{
   $id=$row1["disaster_type_id"];               
 $sql2="select * from tbl_instruction where disaster_type_id='$id'";
$res= $db->execute_query($sql2);
$n=mysqli_num_rows($res);
if($n>0)
{
?>

 <table class="table table-striped table-bordered">
              <thead>
                <tr class="alert alert-info">
                <td colspan="3">Instruction for <?php echo $row1["disaster_type"] ?></td>


                </tr>
              </thead>
              <tbody>
<?php
$count=1;
while($row=mysqli_fetch_array($res))
{
    ?>

    <tr><td style="width: 2%"><?php echo $count; ?></td>
<td><?php echo $row["instruction"] ?></td>


    </tr>
    

    <?php
    $count++;
}
}
else
{
  
 
}
}
?></tbody>
</table>		