<?php session_start(); ?>
<!DOCTYPE HTML>
<html>
<head>
<title>Rescue Guard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Glance Design Dashboard Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<!-- Bootstrap Core CSS -->
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="../css/style.css" rel='stylesheet' type='text/css' />

<!-- font-awesome icons CSS -->
<link href="../css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons CSS-->

<!-- side nav css file -->
<link href='../css/SidebarNav.min.css' media='all' rel='stylesheet' type='text/css'/>
<!-- //side nav css file -->
 
 <!-- js-->
<script src="../js/jquery-1.11.1.min.js"></script>
<script src="../js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts--> 

<!-- chart -->
<script src="../js/Chart.js"></script>
<!-- //chart -->

<!-- Metis Menu -->
<script src="../js/metisMenu.min.js"></script>
<script src="../js/custom.js"></script>
<link href="../css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
<style>
#chartdiv {
  width: 100%;
  height: 295px;
}
</style>
<!--pie-chart --><!-- index page sales reviews visitors pie chart -->
<script src="../js/pie-chart.js" type="text/javascript"></script>
 <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#2dde98',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#8e43e7',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ffc168',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

           
        });

    </script>
<!-- //pie-chart --><!-- index page sales reviews visitors pie chart -->

  <!-- requried-jsfiles-for owl -->
          <link href="../css/owl.carousel.css" rel="stylesheet">
          <script src="../js/owl.carousel.js"></script>
            <script>
              $(document).ready(function() {
                $("#owl-demo").owlCarousel({
                  items : 3,
                  lazyLoad : true,
                  autoPlay : true,
                  pagination : true,
                  nav:true,
                });
              });
            </script>
            <script type="text/javascript" src="../Ajax/ajax.js"></script>
          <!-- //requried-jsfiles-for owl -->
</head> 
<body class="cbp-spmenu-push">
  <?php
if(isset($_SESSION["slogid"]))
{
  ?>
  <div class="main-content">
  <div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
    <!--left-fixed -navigation-->
    <aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">
            <h1><a class="navbar-brand" href="login.php"><span><img src="../images/r.png" style="width:80%"></a></h1>
      
          </div>
          <br>
            <br>
            <br>
            <br>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="sidebar-menu">
              <li class="header"> </li>
              <!--<li class="treeview ">
                <a href="index.php">
                <i class="fa fa-dashboard"></i> <span>Home</span>
                </a>
              </li>-->
               <li class="treeview ">
                <a href="disaster_type.php">
                <i class="fa fa-arrow-circle-right"></i> <span>Disaster Type</span>
                </a>
              </li>
       <li class="treeview">
                <a href="disaster_warning.php">
                <i class="fa fa-sign-in"></i> <span>Disaster Warning</span>
                </a>
              </li>
               <li class="treeview">
                <a href="disaster_warning_list.php">
                <i class="fa fa-user"></i> <span>Disaster Warning List</span>
                </a>
              </li>
              <li class="treeview ">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Camp</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                 <ul class="treeview-menu">
                  <li><a href="add_camp.php"><i class="fa fa-angle-right"></i> Camp</a></li>
                  <li><a href="camp_list.php"><i class="fa fa-angle-right"></i> Camp List</a></li>
                    <li><a href="camp_history.php"><i class="fa fa-angle-right"></i> Camp History</a></li>   
      <li><a href="camp_department.php"><i class="fa fa-angle-right"></i> Camp Department</a></li>            
                
                </ul>
              </li>
              <li class="treeview">
                <a href="sponsers.php">
                <i class="fa fa-user"></i> <span>Sponsers</span>
                </a>
              </li>
              <li class="treeview ">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Location</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                 <ul class="treeview-menu">
                  <li><a href="state.php"><i class="fa fa-angle-right"></i> State</a></li>
                  <li><a href="district.php"><i class="fa fa-angle-right"></i> District</a></li>
                  <li><a href="place.php"><i class="fa fa-angle-right"></i> Place</a></li>
                
                </ul>
              </li>

               <li class="treeview active">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Information</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                 <ul class="treeview-menu">
                  <li><a href="bank.php"><i class="fa fa-angle-right"></i> Bank</a></li>
                  <li><a href="bank_branches.php"><i class="fa fa-angle-right"></i> Bank Branches</a></li>
                  <li><a href="atm.php"><i class="fa fa-angle-right"></i> ATM</a></li>
                  <li><a href="hospital.php"><i class="fa fa-angle-right"></i> Hospital</a></li>
                  <li><a href="police_station.php"><i class="fa fa-angle-right"></i> Police Station</a></li>
                </ul>
              </li>
                
              <li class="treeview">
                <a href="affected_users.php">
                <i class="fa fa-user"></i> <span>Affected Users</span>
                </a>
              </li>
               <li class="treeview ">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Instructions</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                 <ul class="treeview-menu">
                  <li><a href="add_instrctions.php"><i class="fa fa-angle-right"></i> Add Instrctions</a></li>
                  <li><a href="list_instructions.php"><i class="fa fa-angle-right"></i> List Instructions</a></li>
                  
                
                </ul>
              </li>
                <li class="treeview">
                <a href="lost_items.php">
                <i class="fa fa-user"></i> <span>Lost Items List</span>
                </a>
              </li>
                <li class="treeview">
                <a href="complaint.php">
                <i class="fa fa-user"></i> <span>Complaints</span>
                </a>
              </li>
               <li class="treeview">
                <a href="../logout.php">
                <i class="fa fa-sign-out"></i> <span>Log Out</span>
                </a>
              </li>
            </ul>
          </div>
          <!-- /.navbar-collapse -->
      </nav>
    </aside>
  </div>
    <!--left-fixed -navigation-->
    
    <!-- header-starts -->
    <div class="sticky-header header-section ">
      <div class="header-left">
        <!--toggle button start-->
        
        <!--toggle button end-->
        <div class="profile_details_left"><!--notifications of menu start -->
    <div style="margin: 5px 20px;"><h2>RESCUE GUARD </h2></div>
          <div class="clearfix"> </div>
        </div>
        <!--notification menu end -->
        <div class="clearfix"> </div>
      </div>
      <div class="header-right">
        
        
    
        
        <div class="profile_details">   
          <ul>
            <li class="dropdown profile_details_drop">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                <div class="profile_img"> 
                  <span class="prfil-img"><img src="../images/2.jpg" alt=""> </span> 
                  <div class="user-name">
                    <p>Administrator</p>
                    <span>Admin</span>
                  </div>
                  <i class="fa fa-angle-down lnr"></i>
                  <i class="fa fa-angle-up lnr"></i>
                  <div class="clearfix"></div>  
                </div>  
              </a>
              <ul class="dropdown-menu drp-mnu">
                <li> <a href="index.php"><i class="fa fa-cog"></i> Home</a> </li> 
                <li><a href="disaster_type.php">
                <i class="fa fa-arrow-circle-right"></i> <span>Disaster Type</span>
                </a></li>
        <li> <a href="disaster_warning.php">
                <i class="fa fa-user"></i> <span>Disaster Warning</span>
                </a> </li> 
              <li> <a href="disaster_warning_list.php">
                <i class="fa fa-user"></i> <span>Disaster Warning List</span>
                </a> </li> 
                   <li class="">
                <a href="sponsers.php">
                <i class="fa fa-user"></i> <span>Sponsers</span>
                </a>
              </li>
             
               <li class="">
                <a href="affected_users.php">
                <i class="fa fa-user"></i> <span>Affected Users</span>
                </a>
              </li><li>
                <a href="../logout.php">
                <i class="fa fa-sign-out"></i> <span>Log Out</span>
                </a></li>
            </li>
          </ul>
        </div>
        <div class="clearfix"> </div>       
      </div>
      <div class="clearfix"> </div> 
    </div>
    <!-- //header-ends -->
    <!-- main content start-->
    <div id="page-wrapper">
      <div class="main-page">
      <div class="col_3">
          
          <div class="clearfix"> </div>
    </div>
    
  

        
  
  <!-- for amcharts js -->
      <script src="../js/amcharts.js"></script>
      <script src="../js/serial.js"></script>
      <script src="../js/export.min.js"></script>
      <link rel="stylesheet" href="../css/export.css" type="text/css" media="all" />
      <script src="../js/light.js"></script>
  <!-- for amcharts js -->

    <script  src="../js/index1.js"></script>
  
    <div class="charts">    
      <div class="mid-content-top charts-grids">
        <div class="middle-content">
            <h4 class="title">Add Atm</h4>
            <div style="text-align: justify; ">
              
 <form action="hospital_action.php" method="post" name="f1"  id="bankbranch">
          <div class="col-md-5 agileits_mail_grid_left">
          
       <div class="form-group"> 
              <label>Hospital Name</label>               
            
             
             <input type="text" name="hname" class="form-control" placeholder="Hospital..." id="hname"> 
              </div>
             
              <div class="form-group"> 
              <label>State</label>

                            <select name="state" id="state" class="form-control" onchange="display_district()">
                            <option value="">--Select--</option>
                            <?php
                  include('../dbconnection.php');
$db=new dbconnection;                  

$res= $db->execute_query("select * from tbl_state");
while($row=mysqli_fetch_array($res))
{
    ?>
    <option value="<?php echo $row["state_id"]?>"><?php echo $row["state_name"]?></option>

    <?php
}


                                    ?>
                            </select></div>
             <div class="form-group"> 
              <label>District</label>               
            
             
              <select name="district" id="district" class="form-control" onchange="display_place()">
                            <option value="">--Select--</option>
                            </select>
              </div>
               <div class="form-group"> 
              <label>Place</label>               
            
           <select class="form-control" name="city" id="city" >
                            <option value="">--Select--</option>
                            </select>
              </div>
               <div class="form-group"> 
              <label>Proper Place</label>               
            
             
             <input type="text" name="pplace" class="form-control" placeholder="Proper Place..." id="pplace"> 
              </div>
             
  <div class="form-group"> 
              <label>Phone Number</label>               
            
             
             <input type="text" name="phno" class="form-control" placeholder="Phone Number..." id="phno"> 
              </div>
             



            
              <script src="../jquery/jquery.js"></script>
<script src="../jquery/jquery-ui.js"></script>
    <script src="../js/jquery_validate.js"></script>
              <script src="../js/additional_validate.js">

              </script>
              <style type="text/css">
    #bankbranch label.error {
    color: #FB3A3A;
    display: inline-block;
    margin: 0px 0 0px 0px;
    padding: 0;
    text-align: left;
    }
</style>
  <script type="text/javascript">
  (function ($, W, D)
  {
  var JQUERY4U = {};
  JQUERY4U.UTIL =
      {
          setupFormValidation: function ()
          {
            $.validator.addMethod(
    "regex",
    function(value, element, regexp) {
        var check = false;
        return this.optional(element) || regexp.test(value);
    },
    "Not a valid Input."
);
   
          //form validation rules
          $("#bankbranch").validate({
              rules: {
             hname: {
                required:true,
               regex : /^[A-Za-z ]+$/,
                
              },
              phno:
              {
                   required:true,
              minlength: 10,
                       maxlength: 10,
                        regex : /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/
                      },

                state: "required",
              district: "required",
               city: "required",
                pplace: {
                required:true,
                 regex : /^[A-Za-z ]+$/,
                
              },
               
                    latitude: {
                required:true,
              
              },
               longitude: {
                required:true,
              
              },
              },
              messages: {
             
            longitude:"Choose Disaster Location from Google Map..",
                      latitude:"Choose Disaster Location from Google Map..",
              },
              submitHandler: function (form) {
              form.submit();
              }
          });
        }
      }
  //when the dom has loaded setup form validation rules
  $(D).ready(function ($) {
      JQUERY4U.UTIL.setupFormValidation();
  });
  })(jQuery, window, document);
</script>
<script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
    <script type="text/javascript">
        window.onload = function () {
              document.getElementById("longitude").value="";
               document.getElementById("latitude").value="";
                 
            var mapOptions = {
                center: new google.maps.LatLng(9.5595, 76.7874),
                zoom: 14,
                mapTypeId: google.maps.MapTypeId.ROADMAP
            };
            var infoWindow = new google.maps.InfoWindow();
            var latlngbounds = new google.maps.LatLngBounds();
            var map = new google.maps.Map(document.getElementById("dvMap"), mapOptions);
            google.maps.event.addListener(map, 'click', function (e) {
                document.getElementById("longitude").value=e.latLng.lng();
                document.getElementById("latitude").value=e.latLng.lat();
                //alert("Latitude: " + e.latLng.lat() + "\r\nLongitude: " + e.latLng.lng());
            });
              
        }
            
   
    </script>
          </div>
          <div class="col-md-5 agileits_mail_grid_right">
     <div class="form-group"> 
              <label>Branch Location</label>

              <div id="dvMap" style="width: 500px; height: 200px">
    </div>
              </div>
              <div class="form-group"> 
              <label>Longitude</label>
              <input type="text" class="form-control" name='longitude' id="longitude" >
              </div>
<div class="form-group"> 
              <label>Latitude</label>
              <input type="text" class="form-control" name='latitude' id="latitude" >
              </div>

            </div>
            <div class="clearfix"> </div>
              <input type="submit" value="Submit" class="btn btn-info">
            </form>
          <!-- start content_slider -->
        <div class="clearfix"> </div>
        </div>
         <h3 style="width:70%;margin: auto;">Hospital List</h3>
              <?php
                                

$res= $db->execute_query("select * from tbl_hospital  inner join tbl_place on tbl_hospital.place_id = tbl_place.place_id inner join tbl_district on tbl_district.district_id=tbl_place.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id");
$n=mysqli_num_rows($res);
if($n>0)
{
?>
 <table class="table table-striped table-bordered">
              <thead>
                <tr class="alert alert-info">
                  <th>#</th>
                  <th>Hospital Name</th>
                    <th>Place Details</th>
                      <th>Proper Place</th>
                   <th>Delete</th>
                  
                    
                     
                      


                </tr>
              </thead>
              <tbody>
<?php
$count=1;
while($row=mysqli_fetch_array($res))
{
    ?>

    <tr><td><?php echo $count; ?></td><td><?php echo $row["hospital_name"] ?></td>
<td>
 <div><b>Place:</b> <?php echo $row["place_name"] ?></div>
  <div><b>District:</b> <?php echo $row["district_name"] ?></div>
   <div><b>State:</b> <?php echo $row["state_name"] ?></div>
          </td>
          <td><?php echo $row["proper_place_name"] ?></td>
<td><a class="btn btn-danger" href="delete_hospital.php?hospital_id=<?php echo $row["hospital_id"] ?>">Delete</a></td>

    </tr>
    

    <?php
    $count++;
}
}
else
{
  
  ?>
  <div style="padding: 20px; margin:50px; background-color: red; color: #fff">No List Available</div>
  <?php
}
?></tbody>
</table>  
          <!--//sreen-gallery-cursual---->
      </div>
    </div>
    
    <div class="col_1">
      <div class="col-md-4 span_8">
        
          
      </div>
      <div class="col-md-4 span_8">
        
      </div>
      <div class="col-md-4 span_8">
        
        <div class="clearfix"> </div>
      </div>
      <div class="clearfix"> </div>
      
    </div>
        
      </div>
    </div>
  <!--footer-->
  <div class="footer">
     <p> All Rights Reserved | Design by <a href="#" target="_blank">Rescue Guard</a></p>   
  </div>
    <!--//footer-->
  </div>
    
  <!-- side nav js -->
  <script src='../js/SidebarNav.min.js' type='text/javascript'></script>
  <script>
      $('.sidebar-menu').SidebarNav()
    </script>
  <!-- //side nav js -->
  
  <!-- Classie --><!-- for toggle left push menu script -->
    <script src="../js/classie.js"></script>
    <script>
      var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
        showLeftPush = document.getElementById( 'showLeftPush' ),
        body = document.body;
        
      showLeftPush.onclick = function() {
        classie.toggle( this, 'active' );
        classie.toggle( body, 'cbp-spmenu-push-toright' );
        classie.toggle( menuLeft, 'cbp-spmenu-open' );
        disableOther( 'showLeftPush' );
      };
      
      function disableOther( button ) {
        if( button !== 'showLeftPush' ) {
          classie.toggle( showLeftPush, 'disabled' );
        }
      }
    </script>
  <!-- //Classie --><!-- //for toggle left push menu script -->
    
  <!--scrolling js-->
  <script src="../js/jquery.nicescroll.js"></script>
  <script src="../js/scripts.js"></script>
  <!--//scrolling js-->
  
  <!-- Bootstrap Core JavaScript -->
   <script src="../js/bootstrap.js"> </script>
  <?php 
}
else
{
  header("Location:../index.php");
}
  ?>

</body>
</html>