<?php
$state_id=$_GET["state_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from tbl_state where state_id=$state_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("State is deleted Successfully");
              window.location="state.php";

              </script>
            <?php 
        }
?>