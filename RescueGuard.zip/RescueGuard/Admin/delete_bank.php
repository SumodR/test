<?php
$bank_id=$_GET["bank_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from tbl_bank where bank_id=$bank_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Bank is deleted Successfully");
              window.location="bank.php";

              </script>
            <?php 
        }
?>