<?php
$login_id=$_GET["login_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="update tbl_camp set status='Dispersed' where login_id=$login_id";
       $res2=$db->execute_query($sql);
       $d=date("Y-m-d");
     $sql2="update tbl_camp_status set ending_date='$d' where camp_login_id=$login_id and ending_date='0000-00-00'";
       $res3=$db->execute_query($sql2); 
       $sql4="select max(camp_status_id) as s from tbl_camp_status where  camp_login_id=$login_id";
       $camp_status_id=0;
       $res4=$db->execute_query($sql4); 
       while($row=mysqli_fetch_array($res4))
       {
$camp_status_id=$row["s"];
       }  
$sql2="update tbl_affected_people set camp_status_id='$camp_status_id' where camp_login_id=$login_id and camp_status_id='0'";
       $res3=$db->execute_query($sql2);

        if($res2)
            {
              ?>
              <script type="">
                alert("Camp is dispersed Successfully");
              window.location="camp_list.php";

              </script>
            <?php 
        }
?>