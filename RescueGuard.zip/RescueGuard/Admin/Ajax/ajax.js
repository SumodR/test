$(document).ready(function() {


	
	$('#type_save').on('click', function() {
		
		var disaster_type = $('#disaster_type').val();
	
		if(disaster_type!=""){
			$.ajax({
				url: "process_disaster_type.php",
				type: "POST",
				data: {
					disaster_type: disaster_type
				},
				cache: false,
				success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						$('#disaster_type').val('');
						$("#success").show();
							$("#error").hide();
						$('#success').html(dataResult.message); 
						$('#result').html(dataResult.result); 	
											

					}
					else if(dataResult.statusCode==201){
						$("#success").hide();
						$("#error").show();
						$('#error').html('Error occured !'); 
					 
					}
					
				}
			});
		}
		else{
			$("#success").hide();
			$("#error").show();
						$('#error').html('Please fill all the field !'); 
		
		}
	});
	$(document).on('click', '.trash', function(){
   var del_id= $(this).attr('id');
		
		$.ajax({
				url: "process_delete_disaster_type.php",
				type: "POST",
				data: {
					del_id: del_id
				},
				cache: false,
				success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						
						$("#success").show();
							$('#success').html(dataResult.message); 	
						$('#result').html(dataResult.result); 	
											
}
}
					});
});

	$('#disaster_warning_save').on('click', function() {
		
		var disaster_type = $('#disaster_type').val();
		var warning_message = $('#warning_message').val();
var warning_message = $('#warning_message').val();
	var disaster_details = $('#disaster_details').val();
	var region = $('#region').val();
		var disaster_date = $('#datetimepicker').val();
	var longitude = $('#longitude').val();
		var latitude = $('#latitude').val();
			var elongitude = $('#elongitude').val();
				var elatitude = $('#elatitude').val();
		if(disaster_type!=""){
			$.ajax({
				url: "process_disaster_warning.php",
				type: "POST",
				data: {
					disaster_type: disaster_type,
					warning_message:warning_message,
					disaster_details:disaster_details,
					region:region,
				disaster_date:disaster_date,
					longitude:longitude,
					latitude:latitude,
					elongitude:elongitude,
					elatitude:elatitude
				},
				cache: false,
				success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						$('#disaster_type').val('');
						$("#success").show();
							$("#error").hide();
						$('#success').html(dataResult.message); 
						$('#result').html(dataResult.result); 	
											

					}
					else if(dataResult.statusCode==201){
						$("#success").hide();
						$("#error").show();
						$('#error').html('Error occured !'); 
					 
					}
					
				}
			});
		}
		else{
			$("#success").hide();
			$("#error").show();
						$('#error').html('Please fill all the field !'); 
		
		}
	});
	/*$('.trash').on('click', function() {
		
		 var del_id= $(this).attr('id');
		alert(del_id);
		$.ajax({
				url: "process_delete_disaster_type.php",
				type: "POST",
				data: {
					del_id: del_id
				},
				cache: false,
				success: function(dataResult){
					var dataResult = JSON.parse(dataResult);
					if(dataResult.statusCode==200){
						
						$("#success").show();
							$('#success').html(dataResult.message); 	
						$('#result').html(dataResult.result); 	
											
}
}
					});
		});*/


 
    $(".remove").click(function(){

        var id = $(this).parents("tr").attr("id");

        if(confirm('Are you sure to remove this record ?'))

        {

            $.ajax({

               url: 'delete_disaster_warning.php',

               type: 'GET',

               data: {id: id},

               error: function() {

                  alert('Something is wrong');

               },

               success: function(data) {

                    $("#"+id).remove();

                    alert("Record removed successfully");  

               }

            });

        }

    });


});		
function display_search_district()
{
   var state1=document.getElementById("state1").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_search_district.php?state1="+state1,true);
  xmlhttp.send(); 
}
function display_district()
{
   var state=document.getElementById("state").value;


    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('district').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_district.php?state="+state,true);
  xmlhttp.send(); 
}
function display_district1()
{
   var state=document.getElementById("state1").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('district1').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_district.php?state="+state,true);
  xmlhttp.send(); 
}
function display_search_place()
{
   var state1=document.getElementById("state1").value;
 var district1=document.getElementById("district1").value;

if(state1=="0" || district1=="0")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_search_place.php?state1="+state1+"&district1="+district1,true);
  xmlhttp.send(); 
}
}
function display_lost_items_by_camp()
{
 var camp=document.getElementById("camp").value;

if(camp=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_lost_items_by_camp.php?camp="+camp,true);
  xmlhttp.send(); 
}   
}
function display_lost_items_by_date()
{
   var from_date=document.getElementById("from_date").value;
 var to_date=document.getElementById("to_date").value;
if(from_date=="" || to_date=="")
{
 document.getElementById('err1').innerHTML="Please Choose Dates";
    document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;

   
    }
  }
  xmlhttp.open("GET","display_lost_items_by_date.php?from_date="+from_date+"&to_date="+to_date,true);
  xmlhttp.send(); 
}  
}
function display_lost_items_by_phno()
{
 var phno=document.getElementById("phno").value;

if(phno=="")
{
 document.getElementById('err2').innerHTML="Enter Phone Number";
    document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;

   
    }
  }
  xmlhttp.open("GET","display_lost_items_by_phno.php?phno="+phno,true);
  xmlhttp.send(); 
}   
}
function display_lost_items_by_aadhaar_no()
{
  var aadhaar_no=document.getElementById("aadhaar_no").value;

if(aadhaar_no=="")
{
 document.getElementById('err3').innerHTML="Please Enter aadhaar no";
    document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_lost_items_by_aadhaar_no.php?aadhaar_no="+aadhaar_no,true);
  xmlhttp.send(); 
}   
}
function display_camp()
{
var place=document.getElementById("city").value;

if(place=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('camp').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_camp.php?place="+place,true);
  xmlhttp.send(); 
} 
}
function display_place()
{
 var district=document.getElementById("district").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('city').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_place.php?district="+district,true);
  xmlhttp.send();
 
}
function display_instruction_disaster_type()
{
   var disaster_type=document.getElementById("disaster_type").value;

if(disaster_type=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_instruction_disaster_type.php?disaster_type="+disaster_type,true);
  xmlhttp.send(); 
}   
}
function display_affected_people_by_camp()
{
  var camp=document.getElementById("camp").value;

if(camp=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_affected_people_by_camp.php?camp="+camp,true);
  xmlhttp.send(); 
}    
}
function display_affected_people_by_date()
{
   var from_date=document.getElementById("from_date").value;
 var to_date=document.getElementById("to_date").value;
if(from_date=="" || to_date=="")
{
 document.getElementById('err1').innerHTML="Please Choose Dates";
    document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;

   
    }
  }
  xmlhttp.open("GET","display_affected_people_by_date.php?from_date="+from_date+"&to_date="+to_date,true);
  xmlhttp.send(); 
}  
}
function display_affected_people_by_age()
{
     var age=document.getElementById("age").value;

    var camp1=document.getElementById("camp1").value;
 
if(camp1=="" || age=="")
{
 document.getElementById('err5').innerHTML="Please Choose Camp or Age ";
    document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;

   
    }
  }
  xmlhttp.open("GET","display_affected_people_by_age.php?age="+age+"&camp1="+camp1,true);
  xmlhttp.send(); 
}  
}
function display_camp1()
{
var place=document.getElementById("city1").value;

if(place=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('camp1').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_camp.php?place="+place,true);
  xmlhttp.send(); 
} 
}
function display_place1()
{
 var district=document.getElementById("district1").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('city1').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_place.php?district="+district,true);
  xmlhttp.send();
 
}
function display_camp_history()
{
 var camp=document.getElementById("camp").value;

if(camp=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_camp_history.php?camp="+camp,true);
  xmlhttp.send(); 
}  
}