<?php session_start(); ?>
<div  class="alert alert-info">
 <h4 class="title">Camp History</h4><table class="table table-striped">
           <?php
                    include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();
$count=1;
  $cls="odd";
  $camp=$_GET["camp"];

   $sql="select * from  tbl_camp_status inner join tbl_camp on tbl_camp.login_id = tbl_camp_status.camp_login_id   where tbl_camp_status.camp_login_id='$camp' and tbl_camp.status='Working' and tbl_camp_status.ending_date='0000-00-00'";
       $res2=$db->execute_query($sql); 
       if(mysqli_num_rows($res2))
       {
     
       while ($row=mysqli_fetch_array($res2)) {

        ?>
      
          <td>
             <div style="font-size:25px;text-decoration: underline;"><b>Reason:</b> <?php echo $row["reason_for_camp"] ?></div>
 <div style="font-size:20px"><b>Status:</b> <?php echo $row["status"] ?></div>
 <div style="font-size:20px"><b>Starting Date:</b> <?php echo $row["starting_date"] ?></div>
 
          </td>
         
         
        <?php
        $count++;
       }
                            ?></tbody>
                        </table>
<?php }


  $sql1="select * from  tbl_camp_status inner join tbl_camp on tbl_camp.login_id = tbl_camp_status.camp_login_id   where tbl_camp_status.camp_login_id='$camp' and tbl_camp.status='Dispersed'";
       $res1=$db->execute_query($sql1); 
       if(mysqli_num_rows($res1))
       {
     
       while ($row1=mysqli_fetch_array($res1)) {

        ?>
      <tr>
          <td>
              <div style="font-size:25px; text-decoration: underline;"><b>Reason:</b> <?php echo $row1["reason_for_camp"] ?></div>
 <div style="font-size:20px"><b>Status:</b> <?php echo $row1["status"] ?></div>
 <div style="font-size:20px"><b>Starting Date:</b> <?php echo $row1["starting_date"] ?></div> 
<div style="font-size:20px"><b>Dispersed Date:</b> <?php echo $row1["starting_date"] ?></div> </td>
         
         </tr>
         
        <?php
        $count++;
       }
                            ?></tbody>
                        </table>
<?php }

?></div>