<?php
$instruction_id=$_GET["instruction_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from tbl_instruction where instruction_id=$instruction_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Instruction is deleted Successfully");
              window.location="add_instrctions.php";

              </script>
            <?php 
        }
?>