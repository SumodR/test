<?php
$camp_login_id=$_POST["camp_login_id"];
$reason=$_POST["reason"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="update tbl_camp set status='Working' where login_id=$camp_login_id";
       $res2=$db->execute_query($sql);
     $d=date("Y-m-d");
         $sql22="insert into tbl_camp_status(starting_date,camp_login_id,reason_for_camp )values('$d','$camp_login_id','$reason')"; 
           $res22=$db->execute_query($sql22);
        if($res2)
            {
              ?>
              <script type="">
                alert("Camp is Activated Successfully");
              window.location="camp_list.php";

              </script>
            <?php 
        }
?>