<?php
$state=$_POST["state"];

//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

$sql="select * from tbl_state where state_name ='$state'";

        $res=$db->execute_query($sql);
       $c=mysqli_num_rows($res);
  if($c==0)
  {  
 $sql="insert into tbl_state(state_name) values('$state')";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("State is added Successfully");
              window.location="state.php";

              </script>
            <?php 
        }
        }
        else
        {
          ?>
              <script type="">
                alert("State Already Exist.. Try again");
              window.location="state.php";

              </script> 
     <?php    }

?>




