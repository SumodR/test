<?php
include_once("../dbconnection.php");
include_once("sms.php");
 // code to create object of class dboperations
       $db=new dbconnection();
$disaster_type=$_POST['disaster_type'];
$warning_message=$_POST['warning_message'];
$disaster_details=$_POST['disaster_details'];
$region=$_POST['region'];
$disaster_date=$_POST['disaster_date'];
$longitude=$_POST['longitude'];
$latitude=$_POST['latitude'];
$elongitude=$_POST['elongitude'];
$elatitude=$_POST['elatitude'];
$disaster_place=$_POST['disaster_place'];


?>
<?php


$res=$db->execute_query("insert into tbl_disaster_warning(disaster_type_id,warning_message,warning_details,affected_region,date_time,longitude,latitude,disaster_place)values('$disaster_type','$warning_message','$disaster_details','$region','$disaster_date','$longitude','$latitude','$disaster_place')");
$disaster_warning_id=mysqli_insert_id($db->con); 
$array_elongitude=explode(',', $elongitude);
$array_elatitude=explode(',', $elatitude);

for($i=0; $i<count($array_elongitude); $i++)
{
	$res1=$db->execute_query("insert into tbl_evacuation_points(disaster_warning_id, 	evacuation_longitude,evacuation_latitude)values('$disaster_warning_id','$array_elongitude[$i]','$array_elatitude[$i]')");
}
/*Send Message To User Phone, Relative's Phone and Police Authority*/
      function distance($lat1, $lon1, $lat2, $lon2, $unit) {
  if (($lat1 == $lat2) && ($lon1 == $lon2)) {
    return 0;
  }
  else {
    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
    $unit = strtoupper($unit);

    if ($unit == "K") {
      return ($miles * 1.609344);
    } else if ($unit == "N") {
      return ($miles * 0.8684);
    } else {
      return $miles;
    }
  }
}
$d=date("Y-m-d");
   $sql="select * from tbl_user_position inner join tbl_user_registration on tbl_user_registration.login_id=tbl_user_position.user_login_id where date(entry_date)='$d'";
    $res=$db->execute_query($sql);
    $r= mysqli_num_rows($res);
    $relative_phone_number=array();
     $phone_number=array();
     $name_list=array();
if($r>0)
{
$user_longitude="";
$user_latitude="";
$i=0;
while($row=mysqli_fetch_array($res))
{
	$name=$row["firstname"]." ".$row["lastname"]." ,".$row["house_name"];
	$rphno=$row["relative_phone_number"];
  $user_longitude=$row["longitude"];
$user_latitude=$row["latitude"];
  $uphno=$row["phone_number"];
  $dist=distance($user_latitude,$user_longitude,$latitude,$longitude,"K");
   if($region>= $dist)
   {
 $name_list[$i]=$name;
$relative_phone_number[$i]=$rphno;
$phone_number[$i]=$uphno;
$i++;
}
}
}
/*-----------------*/

//Policestation Phone Number
  $sql2="select * from tbl_police_station ";
    $res2=$db->execute_query($sql2);
    $r2= mysqli_num_rows($res2);
    $police_phone_number=array();
     $hospital_phone_number=array();
if($r2>0)
{

$k=0;
$police_longitude=0;
$police_latitude=0;
while($row2=mysqli_fetch_array($res2))
{
    $police_longitude=$row2["longitude"];
$police_latitude=$row2["latitude"];
  $uphno=$row2["phone_number"];
  $dist2=distance($police_latitude,$police_longitude,$latitude,$longitude,"K");
   if($region>= $dist2)
   {
     $police_phone_number[$k]=$uphno;
     $k++;
   }
}
}

//End Policestation Phone Number
/*-----------------*/
/*-----------------*/

//Policestation Phone Number
  $sql3="select * from tbl_hospital ";
    $res3=$db->execute_query($sql3);
    $r3= mysqli_num_rows($res3);
   $hphno=0;
if($r3>0)
{

$l=0;
$hospital_longitude=0;
$hospital_latitude=0;
while($row3=mysqli_fetch_array($res3))
{
    $hospital_longitude=$row3["longitude"];
$hospital_latitude=$row3["latitude"];
  $hphno=$row3["phone_number"];
  $dist3=distance($hospital_latitude,$hospital_longitude,$latitude,$longitude,"K");
   if($region>= $dist3)
   {
     $hospital_phone_number[$l]=$hphno;
     $l++;
   }
}
}

//End Policestation Phone Number

$obj=new sms;
for($w=0;$w<count($relative_phone_number); $w++)
{
  $msg1="Your Relative, $name_list[$w] is in Disaster Affected Area!!, $warning_message";
$obj->sendsms($relative_phone_number[$w],$msg1);
}
for($x=0;$x<count($phone_number); $x++)
{
  $msg2="You are  in Disaster Affected Area, Please login to Disaster Management Web Site !!... $warning_message";
$obj->sendsms($phone_number[$x],$msg2);
}
for($y=0;$y<count($police_phone_number); $y++)
{
  $msg3="A Speacial Alert From Disaster Management Authority.  $warning_message";
$obj->sendsms($police_phone_number[$y],$msg3);
}
for($z=0;$z<count($police_phone_number); $z++)
{
  $msg4="A Speacial Alert From Disaster Management Authority.  $warning_message";
$obj->sendsms($hospital_phone_number[$z],$msg4);
}



if ($res) {
?>
              <script type="">
                alert("warning is added successfully");
              window.location="disaster_warning.php";

              </script> 
	<?php }


  
?>