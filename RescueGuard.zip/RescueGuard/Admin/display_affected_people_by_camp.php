						 <?php
                    include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();
$count=1;
  $cls="odd";
  $logid=$_GET["camp"];
  $sql="select * from  tbl_affected_people inner join tbl_camp on tbl_affected_people.camp_login_id=tbl_camp.login_id inner join tbl_place on tbl_affected_people.place_id = tbl_place.place_id inner join tbl_district on tbl_district.district_id=tbl_place.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id  where tbl_affected_people.camp_login_id='$logid' order by tbl_affected_people.affected_people_id desc";
       $res2=$db->execute_query($sql); 
       if(mysqli_num_rows($res2))
       {
        ?>
         <table class="table table-bordered">
    
    
    <thead>
                            <tr class="alert alert-info"><th>#</th>
                              <th> Name</th>
<th>Gender</th>

<th>Place</th>
<th>Phone Number</th>
  <th>Description</th>                            </tr></thead><tbody>
        <?php
       while ($row=mysqli_fetch_array($res2)) {

        ?>
        <tr><td><?php echo $count; ?></td>
          <td><?php echo $row["affected_people_name"] ?></td>  
           <td><?php echo $row["gender"] ?></td> 
           <td>
          
 <div><b>Place:</b> <?php echo $row["place_name"] ?></div>
  <div><b>District:</b> <?php echo $row["district_name"] ?></div>
   <div><b>State:</b> <?php echo $row["state_name"] ?></div>
          </td> 
               <td><?php echo $row["affected_user_phone_no"] ?></td> 
                          <td><?php echo $row["description"] ?></td> 
                            <td><?php echo $row["camp_name"] ?></td>        
        </tr>
        <?php
        $count++;
       }
                            ?></tbody>
                        </table>
<?php }

else
{
  ?>
  <div class="alert alert-info">No Records Found</div>
  <?php
} ?>	