<?php
$bank=$_POST["bank"];
$city=$_POST["city"];
$pplace=$_POST["pplace"];
$longitude=$_POST["longitude"];
$latitude=$_POST["latitude"];

//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();
 
   $sql="insert into tbl_bank_branches(bank_id, place_id, longitude, latitude, proper_place_name) values('$bank','$city','$longitude','$latitude','$pplace')";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("Branch is added Successfully");
              window.location="bank_branches.php";

              </script>
            <?php 
        }
       ?>




