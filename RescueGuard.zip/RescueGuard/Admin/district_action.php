<?php
$state=$_POST["state"];
$district=$_POST["district"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

$sql="select * from tbl_district where district_name ='$district' and state_id='$state'";

        $res=$db->execute_query($sql);
       $c=mysqli_num_rows($res);
  if($c==0)
  {  
 $sql="insert into tbl_district(state_id,district_name) values('$state','$district')";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("District is added Successfully");
              window.location="district.php";

              </script>
            <?php 
        }
        }
        else
        {
          ?>
              <script type="">
                alert("District Already Exist.. Try again");
              window.location="district.php";

              </script> 
     <?php    }

?>




