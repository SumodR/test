<?php 
include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();
$disaster_type=$_POST['disaster_type'];
$warning_message=$_POST['warning_message'];
$disaster_details=$_POST['disaster_details'];
$region=$_POST['region'];
$disaster_date=$_POST['disaster_date'];
$longitude=$_POST['longitude'];
$latitude=$_POST['latitude'];
$elongitude=$_POST['elongitude'];
$elatitude=$_POST['elatitude'];
$disaster_place=$_POST['disaster_place'];

      function distance($lat1, $lon1, $lat2, $lon2, $unit) {
  if (($lat1 == $lat2) && ($lon1 == $lon2)) {
    return 0;
  }
  else {
    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) +  cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
    $unit = strtoupper($unit);

    if ($unit == "K") {
      return ($miles * 1.609344);
    } else if ($unit == "N") {
      return ($miles * 0.8684);
    } else {
      return $miles;
    }
  }
}

$d=date("Y-m-d");
   $sql="select * from tbl_user_position inner join tbl_user_registration on tbl_user_registration.login_id=tbl_user_position.user_login_id where date(entry_date)='$d'";
    $res=$db->execute_query($sql);
    $r= mysqli_num_rows($res);
     $relative_phone_number_array=array();
if($r>0)
{
$user_longitude="";
$user_latitude="";
while($row=mysqli_fetch_array($res))
{
	$name=$row["firstname"]." ".$row["lastname"]." ,".$row["house_name"];
	$rphno=$row["relative_phone_number"];
  $user_longitude=$row["longitude"];
$user_latitude=$row["latitude"];

  $dist=distance($user_latitude,$user_longitude,$latitude,$longitude,"K");
  $relative_phone_number_array=array();
  $i=0;
   if($region>= $dist)
   {
    $relative_phone_number_array[$i]=$row["relative_phone_number"];
    $i++;
   }
 }
}
var_dump($relative_phone_number_array);
 ?>


