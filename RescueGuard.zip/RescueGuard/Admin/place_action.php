<?php
$place=$_POST["place"];
$district=$_POST["district"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

$sql="select * from tbl_place where district_id ='$district' and place_name='$place'";

        $res=$db->execute_query($sql);
       $c=mysqli_num_rows($res);
  if($c==0)
  {  
 $sql="insert into tbl_place(district_id,place_name) values('$district','$place')";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("Place is added Successfully");
              window.location="place.php";

              </script>
            <?php 
        }
        }
        else
        {
          ?>
              <script type="">
                alert("District Already Exist.. Try again");
              window.location="district.php";

              </script> 
     <?php    }

?>




