 <?php
                    include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();
$count=1;
  $cls="odd";
$camp=$_GET["camp"];
  $sql="select * from  tbl_camp_requirements inner join tbl_required_item on tbl_camp_requirements.item_id=tbl_required_item.item_id  inner join tbl_camp on tbl_required_item.camp_login_id= tbl_camp.login_id inner join tbl_place on tbl_camp.place_id = tbl_place.place_id inner join tbl_district on tbl_district.district_id=tbl_place.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id  where tbl_required_item.camp_login_id='$camp' order by tbl_camp_requirements.entry_date desc";
       $res2=$db->execute_query($sql); 
       if(mysqli_num_rows($res2))
       {
        ?>
         <table class="table table-bordered">
    
    
    <thead>
                            <tr class="alert alert-info"><th>No.</th>
                              <th>Item</th>
<th>Quantity</th>
<th>Unit</th>
<th>Camp Name</th>
<th>Camp Place</th>
<th>Camp Capacity</th>
<th>Date</th>


                              <th>Sponser Items</th></tr></thead><tbody>
        <?php
       while ($row=mysqli_fetch_array($res2)) {

        ?>
        <tr><td><?php echo $count; ?></td>
          <td><?php echo $row["item"] ?></td>  
           <td><?php echo $row["quantity"] ?></td> 
              <td><?php echo $row["unit"] ?></td> 
              <td><?php echo $row["camp_name"] ?></td>

<td>
 <div><b>Place:</b> <?php echo $row["place_name"] ?></div>
  <div><b>District:</b> <?php echo $row["district_name"] ?></div>
   <div><b>State:</b> <?php echo $row["state_name"] ?></div>
          </td>
              <td><?php echo $row["capacity"] ?></td>
               <td><?php echo $row["entry_date"] ?></td>    
        <td><a class="btn btn-success" href="sponsor_items.php?required_id=<?php echo $row["required_id"] ?>">Sponser This Item</a></td>

 </tr>
        <?php
        $count++;
       }
                            ?></tbody>
                        </table>
<?php }

else
{
  ?>
  <div class="alert alert-info">No Records Found</div>
  <?php
} ?>  