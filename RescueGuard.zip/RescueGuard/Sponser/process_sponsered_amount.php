              <?php 
              session_start();
        //Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

 $logid=$_SESSION["slogid"];    
if (isset($_POST['submit'])) 
{
  
$camp_login_id=$_POST["camp_login_id"];

$amount=$_POST["amount"];
$date=$_POST["date"];

  $sql="insert into tbl_sponser_payment(  amount ,  sponser_login_id ,  camp_login_id ,  payment_date) values('$amount','$logid','$camp_login_id','$date')";
       $res1=$db->execute_query($sql); 
      $payment_id = mysqli_insert_id($db->con); 
   header("location:payment/TxnTest.php?payment_id= $payment_id");
       

}
          ?> 