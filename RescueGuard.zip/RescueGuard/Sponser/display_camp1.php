       <?php
include('../dbconnection.php');
$db=new dbconnection;                            
         $place_id=$_GET["place"];
$res= $db->execute_query("select * from tbl_camp inner join tbl_place on tbl_camp.place_id = tbl_place.place_id inner join tbl_district on tbl_district.district_id=tbl_place.district_id inner join tbl_state on tbl_state.state_id=tbl_district.state_id where tbl_camp.place_id='$place_id'  and tbl_camp.status='Working'");
$n=mysqli_num_rows($res);
if($n>0)
{
?>
 <table class="table table-striped table-bordered">
              <thead>
                <tr class="alert alert-info">
                  <th>#</th>
                  <th>Camp Name</th>
                   <th>Place Details</th>
                    <th>Capacity</th>
                      <th>Registered Date</th>
                <th></th>
                    
                     
                      


                </tr>
              </thead>
              <tbody>
<?php
$count=1;
while($row=mysqli_fetch_array($res))
{
    ?>

    <tr><td><?php echo $count; ?></td><td><?php echo $row["camp_name"] ?></td>

<td>
 <div><b>Place:</b> <?php echo $row["place_name"] ?></div>
  <div><b>District:</b> <?php echo $row["district_name"] ?></div>
   <div><b>State:</b> <?php echo $row["state_name"] ?></div>
          </td>
              <td><?php echo $row["capacity"] ?></td>
         <td><?php echo $row["reg_date"] ?></td>

 <td><a class="btn btn-success" href="add_sponser_amount.php?camp_login_id=<?php echo $row["login_id"] ?>">Sponser Amount</a></td>

    </tr>
    

    <?php
    $count++;
}
}
else
{
  
  ?>
  <div class="alert alert-info" style="padding: 20px; margin:50px;">No List Available</div>
  <?php
}
?></tbody>
</table> 