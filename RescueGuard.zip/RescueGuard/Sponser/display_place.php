
									<option value="0">--Select--</option>
									<?php
									$district=$_GET["district"];
									
include('../dbconnection.php');
$db=new dbconnection;
$res= $db->execute_query("select * from tbl_place inner join tbl_camp on tbl_camp.place_id=tbl_place.place_id where tbl_place.district_id=$district and tbl_camp.status='Working' group by tbl_camp.place_id order by place_name ");
while($row=mysqli_fetch_array($res))
{
	?>
	<option value="<?php echo $row["place_id"]?>"><?php echo $row["place_name"]?></option>

	<?php
}


									?>