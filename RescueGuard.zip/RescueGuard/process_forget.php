 
<?php 


$email_address = strip_tags(htmlspecialchars($_POST['emailid']));
//Include dboperation class file 
 include_once("dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

$email_address = strip_tags(htmlspecialchars($_POST['emailid']));

$sql="select * from tbl_user_registration where email_id='$email_address'";

        $res=$db->execute_query($sql);
       $c=mysqli_num_rows($res);
  if($c>0)
  {  

   
// Create the email and send the message
$to = $email_address;
$subject="sddsd"; // Add your email address inbetween the '' replacing yourname@yourdomain.com - This is where the form will send a message to.
$email_subject = "Rescue Guard Forget password";
$email_body = '<html><body>';
$email_body .= 'Click Here ';

$email_body .= "<a href='http://localhost:8080//Rescue Guard/newpassword.php'> Click Here For New Password </a>";

$email_body .= "</body></html>";
//$headers = "From: noreply@yourdomain.com\n"; // This is the email address the generated message will be from. We recommend using something like noreply@yourdomain.com.
$headers = "From:  Noreply@domain.com \r\n";
			$headers .= "Reply-To: Noreply@domain.com\r\n";
			$headers .= "MIME-Version: 1.0\r\n";
			$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";

$headers .= "Reply-To: $email_address";   
 $result=mail($to,$email_subject,$email_body,$headers);
 if(!$result) {   ?>
        <script type="">
                alert("Weak Network or not a valid email Id");
              window.location="login.php";

              </script>  
<?php } else {
 
   ?>
              <script type="">
                alert("Change Password Link has been sent to Your Mail Id");
              window.location="login.php";

              </script> 
      
   <?php
 }
 }
        else
        {
          ?>
              <script type="">
                alert("Not a valid Email ID.. Try again");
              window.location="login.php";

              </script> 
     <?php    }

?>




