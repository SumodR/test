<?php
$staff_id=$_GET["staff_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from tbl_camp_staff where staff_id=$staff_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Staff is deleted Successfully");
              window.location="staff_list.php";

              </script>
            <?php 
        }
?>