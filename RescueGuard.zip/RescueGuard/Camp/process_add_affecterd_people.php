<?php
session_start();
$aff_user=$_POST["aff_user"];
$city=$_POST["city"];

$address=$_POST["address"];
$dob=$_POST["dob"];
$gender=$_POST["gender"];
$phone_no=$_POST["phone_no"];
$description=$_POST["description"];
$logid=$_SESSION["slogid"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();
$camp_status_id=0;
 $sql6="select camp_status_id from  tbl_camp_status inner join tbl_camp on tbl_camp.login_id = tbl_camp_status.camp_login_id   where tbl_camp_status.camp_login_id='$logid' and tbl_camp.status='Working' and tbl_camp_status.ending_date='0000-00-00'";
       $res6=$db->execute_query($sql6); 
     
       
if(mysqli_num_rows($res6)>0)
{
  while ($row6=mysqli_fetch_array($res6)) {
$camp_status_id=$row6["camp_status_id"];
      }
 $sql22="select * from tbl_affected_people where address='$address' and affected_people_name='$aff_user' and camp_login_id='$logid' and affected_user_phone_no='$phone_no'";
       $res22=$db->execute_query($sql22); 
$n=mysqli_num_rows($res22);



if($n==0)
{

 $sql="insert into  tbl_affected_people(   affected_people_name ,  gender ,  affected_user_phone_no ,  description ,  place_id ,  camp_login_id,address,date_of_birth,camp_status_id ) values('$aff_user','$gender','$phone_no','$description','$city','$logid','$address','$dob','$camp_status_id')";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("Affected People's record  is added Successfully");
              window.location="add_affected_people.php";

              </script>
            <?php 
        }
}
else
{
 ?>
              <script type="">
                alert("People Already Exist");
              window.location="add_affected_people.php";

              </script>
            <?php  
}


}
else
{
  ?>
              <script type="">
                alert("This Camp is Not Active");
              window.location="add_affected_people.php";

              </script>
            <?php  
}
