<?php 
session_start();

$ration_card_number=$_POST["ration_card_number"];
$aadhar_no=$_POST["aadhar_no"];
$phone_no=$_POST["phone_no"];
$description=$_POST["description"];
$bank=$_POST["bank"];
$ifsc=$_POST["ifsc"];
$acno=$_POST["acno"];
$lost_items_id=$_POST["lost_items_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();


 $sql="update tbl_lost_items set ration_card_number='$ration_card_number', aadhaar_no='$aadhar_no', phone_number='$phone_no', description='$description', bank_id='$bank', account_number='$acno', ifsc_code='$acno' where lost_items_id='$lost_items_id'";
       $res1=$db->execute_query($sql); 
      
   
            if($res1)
            {
              ?>
              <script type="">
                alert("Updated Successfully");
              window.location="lost_item_details.php";

              </script>
            <?php 
        }
       
?>
