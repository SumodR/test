<?php
$item_id=$_GET["item_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from tbl_required_item where item_id=$item_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Item is deleted Successfully");
              window.location="required_item.php";

              </script>
            <?php 
        }
?>