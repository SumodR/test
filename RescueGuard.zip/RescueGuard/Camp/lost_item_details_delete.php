<?php
$lost_items_id=$_GET["lost_items_id"];
//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();

  
 $sql="delete from tbl_lost_items where lost_items_id=$lost_items_id";
       $res2=$db->execute_query($sql);
        if($res2)
            {
              ?>
              <script type="">
                alert("Lost Item is deleted Successfully");
              window.location="lost_item_details.php";

              </script>
            <?php 
        }
?>