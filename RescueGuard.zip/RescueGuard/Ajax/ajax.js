function display_state()
{
  var country=document.getElementById("country").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('state').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_state.php?country="+country,true);
  xmlhttp.send();

}
function display_district()
{
  var state=document.getElementById("state").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('district').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_district.php?state="+state,true);
  xmlhttp.send();

}
function display_place()
{
 var district=document.getElementById("district").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('city').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_place.php?district="+district,true);
  xmlhttp.send();
 
}
function display_camp()
{
var place=document.getElementById("city").value;

if(place=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_camp.php?place="+place,true);
  xmlhttp.send(); 
} 
}
function display_camp_name()
{
 var place=document.getElementById("city").value;

if(place=="")
{

}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('camp').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_camp_name.php?place="+place,true);
  xmlhttp.send(); 
}  
}
function display_required_items()
{
  var camp=document.getElementById("camp").value;

if(camp=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_required_items.php?camp="+camp,true);
  xmlhttp.send(); 
} 
}
function display_camp1()
{
 var place=document.getElementById("city").value;

if(place=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_camp1.php?place="+place,true);
  xmlhttp.send(); 
} 
}
function display_bank()
{
var place=document.getElementById("city").value;

if(place=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_bank.php?place="+place,true);
  xmlhttp.send(); 
} 
}
function display_bank1()
{
  var longitude=document.getElementById("longitude").value;
var latitude=document.getElementById("latitude").value;
if(latitude=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_bank1.php?latitude="+latitude+"&longitude="+longitude,true);
  xmlhttp.send(); 
} 
}
function display_atm()
{
 var place=document.getElementById("city").value;

if(place=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_atm.php?place="+place,true);
  xmlhttp.send(); 
}  
}
function display_atm1()
{
   var longitude=document.getElementById("longitude").value;
var latitude=document.getElementById("latitude").value;
if(latitude=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_atm1.php?latitude="+latitude+"&longitude="+longitude,true);
  xmlhttp.send(); 
} 
}
function display_place_list()
{
 var district=document.getElementById("district").value;
 

    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('city').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_place_list.php?district="+district,true);
  xmlhttp.send();
 
}
function display_hospital()
{
 var place=document.getElementById("city").value;

if(place=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_hospital.php?place="+place,true);
  xmlhttp.send(); 
}  
}
function display_hospital1()
{
   var longitude=document.getElementById("longitude").value;
var latitude=document.getElementById("latitude").value;
if(latitude=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_hospital1.php?latitude="+latitude+"&longitude="+longitude,true);
  xmlhttp.send(); 
} 
}
function display_police_station()
{
 var place=document.getElementById("city").value;

if(place=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_police_station.php?place="+place,true);
  xmlhttp.send(); 
}   
}
function display_police_station1()
{
  var longitude=document.getElementById("longitude").value;
var latitude=document.getElementById("latitude").value;
if(latitude=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_police_station1.php?latitude="+latitude+"&longitude="+longitude,true);
  xmlhttp.send(); 
} 
}
function display_lost_items_by_city()
{
 var place=document.getElementById("city").value;

if(place=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_lost_items_by_city.php?place="+place,true);
  xmlhttp.send(); 
}   
}
function display_lost_items_by_date()
{
   var from_date=document.getElementById("from_date").value;
 var to_date=document.getElementById("to_date").value;
if(from_date=="" || to_date=="")
{
 document.getElementById('err1').innerHTML="Please Choose Dates";
    document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;

   
    }
  }
  xmlhttp.open("GET","display_lost_items_by_date.php?from_date="+from_date+"&to_date="+to_date,true);
  xmlhttp.send(); 
}  
}
function display_lost_items_by_phno()
{
 var phno=document.getElementById("phno").value;

if(phno=="")
{
 document.getElementById('err2').innerHTML="Enter Phone Number";
    document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;

   
    }
  }
  xmlhttp.open("GET","display_lost_items_by_phno.php?phno="+phno,true);
  xmlhttp.send(); 
}   
}
function display_lost_items_by_aadhaar_no()
{
  var aadhaar_no=document.getElementById("aadhaar_no").value;

if(aadhaar_no=="")
{
 document.getElementById('err3').innerHTML="Please Enter aadhaar no";
    document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_lost_items_by_aadhaar_no.php?aadhaar_no="+aadhaar_no,true);
  xmlhttp.send(); 
}   
}
function display_instruction_disaster_type()
{
   var disaster_type=document.getElementById("disaster_type").value;

if(disaster_type=="")
{
 document.getElementById('result').innerHTML="";
}
else
{
    if (window.XMLHttpRequest) {
    // code for IE7+, Firefox, Chrome, Opera, Safari
    xmlhttp=new XMLHttpRequest();
  } else { // code for IE6, IE5
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
    
      document.getElementById('result').innerHTML=xmlhttp.responseText;
   
    }
  }
  xmlhttp.open("GET","display_instruction_disaster_type.php?disaster_type="+disaster_type,true);
  xmlhttp.send(); 
}   
}
