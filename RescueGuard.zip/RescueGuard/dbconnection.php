<?php
/**
 * 
 */
class dbconnection 
{
	var $con;
	Var $res;
	
	function __construct()
	{
	$this->con=mysqli_connect("localhost","root","","amal_jyothi_rescue_guard_new");
}
function execute_query($sql)
{
	$this->res=mysqli_query($this->con,$sql);
	return $this->res;
}
}
?>