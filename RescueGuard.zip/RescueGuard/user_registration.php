<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Rescue Guard</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Glance Design Dashboard Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<!-- Bootstrap Core CSS -->
<link href="css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />

<!-- font-awesome icons CSS -->
<link href="css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons CSS-->

<!-- side nav css file -->
<link href='css/SidebarNav.min.css' media='all' rel='stylesheet' type='text/css'/>
<!-- //side nav css file -->
 
 <!-- js-->
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts--> 

<!-- chart -->
<script src="js/Chart.js"></script>
<!-- //chart -->

<!-- Metis Menu -->
<script src="js/metisMenu.min.js"></script>
<script src="js/custom.js"></script>
<link href="css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
<style>
#chartdiv {
  width: 100%;
  height: 295px;
}
</style>
<!--pie-chart --><!-- index page sales reviews visitors pie chart -->
<script src="js/pie-chart.js" type="text/javascript"></script>
 <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#2dde98',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#8e43e7',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ffc168',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

           
        });

    </script>
<!-- //pie-chart --><!-- index page sales reviews visitors pie chart -->

	<!-- requried-jsfiles-for owl -->
					<link href="css/owl.carousel.css" rel="stylesheet">
					<script src="js/owl.carousel.js"></script>
						<script>
							$(document).ready(function() {
								$("#owl-demo").owlCarousel({
									items : 3,
									lazyLoad : true,
									autoPlay : true,
									pagination : true,
									nav:true,
								});
							});
						</script>
						<script type="text/javascript" src="Ajax/ajax.js"></script>
					<!-- //requried-jsfiles-for owl -->
					<script type="text/javascript" src="jquery/jquery.js"></script>
<script type="text/javascript" src="jquery/jquery-ui.js"></script>
<script type="text/javascript" src="jquery/jquery-ui.min.js"></script>
<link href="jquery/jquery-ui.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="validation.js"></script>
<script>
$(function() {
 

	$( "#dob" ).datepicker({ dateFormat: 'yy-mm-dd', changeMonth: true,
changeYear: true,maxDate:0  });

	
  });</script>
</head> 
<body class="cbp-spmenu-push">
	<div class="main-content">
	<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
		<!--left-fixed -navigation-->
		<aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">
             <h1><a class="navbar-brand" href="login.php"><span><img src="images/r.png" style="width:80%"></a></h1>
      
          </div>
          <br>
            <br>
            <br>
            <br>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="sidebar-menu">
              <li class="header"></li>
              <li class="treeview">
                <a href="index.php">
                <i class="fa fa-dashboard"></i> <span>Home</span>
                </a>
              </li>
               <li class="treeview">
                <a href="about_us.php">
                <i class="fa fa-arrow-circle-right"></i> <span>About Us</span>
                </a>
              </li>
			 <li class="treeview">
                <a href="login.php">
                <i class="fa fa-sign-in"></i> <span>Login</span>
                </a>
              </li>
               <li class="treeview">
                <a href="user_registration.php">
                <i class="fa fa-user"></i> <span>User Registration</span>
                </a>
              </li>
               <li class="treeview">
                <a href="sponser_registration.php">
                <i class="fa fa-user"></i> <span>Sponser Registration</span>
                </a>
              </li>
               <li class="treeview">
                <a href="instructions.php">
                <i class="fa fa-user"></i> <span>Instructions</span>
                </a>
            </li>
            </ul>
          </div>
          <!-- /.navbar-collapse -->
      </nav>
    </aside>
	</div>
		<!--left-fixed -navigation-->
		
		<!-- header-starts -->
		<div class="sticky-header header-section ">
			<div class="header-left">
				<!--toggle button start-->
				
				<!--toggle button end-->
				<div class="profile_details_left"><!--notifications of menu start -->
		
					<div class="clearfix"> </div>
				</div>
				<!--notification menu end -->
				<div class="clearfix"> </div>
			</div>
			<div class="header-right">
				
				
				
				<div class="profile_details">		
					<ul>
						<li class="dropdown profile_details_drop">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
								<div class="profile_img">	
									<span class="prfil-img"><img src="images/2.jpg" alt=""> </span> 
									<div class="user-name">
										<p>Guest User</p>
										<span>Guest</span>
									</div>
									<i class="fa fa-angle-down lnr"></i>
									<i class="fa fa-angle-up lnr"></i>
									<div class="clearfix"></div>	
								</div>	
							</a>
							<ul class="dropdown-menu drp-mnu">
								<li> <a href="index.php"><i class="fa fa-cog"></i> Home</a> </li> 
								<li> <a href="about_us.php"><i class="fa-arrow-circle-right"></i> About Us</a> </li> 
								<li> <a href="login.php"><i class="fa fa-sign-in"></i> Login</a> </li> 
								<li> <a href="user_registration.php"><i class="fa fa-user"></i> User Registration</a> </li>
								 <li >
                <a href="sponser_registration.php">
                <i class="fa fa-user"></i> <span>Sponser Registration</span>
                </a>
              </li>
							</ul>
						</li>
					</ul>
				</div>
				<div class="clearfix"> </div>				
			</div>
			<div class="clearfix"> </div>	
		</div>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
			<div class="col_3">
        	
        	<div class="clearfix"> </div>
		</div>
		
	

				
	
	<!-- for amcharts js -->
			<script src="js/amcharts.js"></script>
			<script src="js/serial.js"></script>
			<script src="js/export.min.js"></script>
			<link rel="stylesheet" href="css/export.css" type="text/css" media="all" />
			<script src="js/light.js"></script>
	<!-- for amcharts js -->

    <script  src="js/index1.js"></script>
	
		<div class="charts">		
			<div class="mid-content-top charts-grids">
				<div class="middle-content">
						
						<div style="text-align: justify; ">
							
						<div class="form-grids row widget-shadow" data-example-id="basic-forms"> 
						<div class="form-title">
              <center>
							<h2>User Registration</h2></center>
						</div>
						<div class="form-body">

							<form action="process_registraion_action.php" method="post" name="f1" id="myForm"> 
<div class="col-md-6">

								<table width="100%"  cellpadding="5"><tr><td>First Name</td><td><input type="text" placeholder="First Name..."  class="form-control" name="fname" id="fname"  >

								</td></tr>
                    <tr><td>Last Name</td><td>
                    <input type="text" placeholder="Last Name..." class="form-control" name="lname" id="lname">

                </td></tr>
    <tr><td>State :</td><td>
                            <select name="state" id="state" class="form-control" onchange="display_district()">
                            <option value="">--Select--</option>
                            <?php
                                    
include('dbconnection.php');
$db=new dbconnection;
$res= $db->execute_query("select * from tbl_state");
while($row=mysqli_fetch_array($res))
{
    ?>
    <option value="<?php echo $row["state_id"]?>"><?php echo $row["state_name"]?></option>

    <?php
}


                                    ?>
                            </select>

                        </td></tr>

                            <tr><td>District :</td><td>
                            <select name="district" id="district" class="form-control" onchange="display_place()">
                            <option value="">--Select--</option>
                            </select>
                       </td></tr>

                            <tr><td>City :</td><td>
                            <select class="form-control" name="city" id="city">
                            <option value="">--Select--</option>
                            </select>
                       </td></tr>


                            
                           
                              <tr><td>House Name :</td><td>
                            <input type="text" name="hname" class="form-control" id="hname">

                        </td></tr>
                <tr><td>Gender :</td><td>
            <input   type="radio" name="gender" id="gender" value="Male" checked="">Male
<input   type="radio" name="gender" id="gender" value="Female">Female

        </td></tr>

 </table>


</div>
<div class="col-md-6"><table cellpadding="5" width="100%" >
	
          <tr><td>Date of Birth :</td><td>
            <input class="form-control"  type="text" name="dob" readonly="" id="dob">

        </td></tr>
                          
                 <tr><td>Phone Number :</td><td>
            <input class="form-control"  type="text" name="phone_no" id="phone_no">

        </td></tr>
             <tr><td>Relative Phone Number :</td><td>
            <input class="form-control"  type="text" name="rphone_no" id="rphone_no"></td></tr>
                            <tr><td>Email Id :</td><td>
                            <input class="form-control" type="text" name="emailid" id="emailid"></td></tr>
   
                           <tr><td>Username :</td><td>

                    <input class="form-control" type="text" placeholder="Username "  name="username" id="username" ></td></tr>
                    <tr><td>Password :</td><td>
                    <input class="form-control" type="password" placeholder="Password"  id="password" name="password" ></td></tr>
                    <tr><td>Confirm Password :</td><td>
                    <input class="form-control" type="password" placeholder="Password Confirmation" id="cpassword"  name="cpassword"></td></tr>
                    
                
                </table>
	</div>
	<div class="clearfix"> </div><center>
								 <button type="submit" class="btn btn-default">Submit</button></center> </form> 
								 <style type="text/css">
    #myForm label.error {
    color: #FB3A3A;
    display: inline-block;
    margin: 0px 0 0px 0px;
    padding: 0;
    text-align: left;
    }
</style>
						

    <!-- jQuery Form Validation library -->
    <script src="js/jquery_validate.js">
              </script>
	<script type="text/javascript">
  (function ($, W, D)
  {
  var JQUERY4U = {};
  JQUERY4U.UTIL =
      {
          setupFormValidation: function ()
          {
          	$.validator.addMethod(
    "regex",
    function(value, element, regexp) {
        var check = false;
        return this.optional(element) || regexp.test(value);
    },
    "Not a valid Input."
);
   
          //form validation rules
          $("#myForm").validate({
              rules: {
              fname: {
              	required:true,
              	regex :/^[a-zA-Z]+$/
              },
              lname: {
              	required:true,
              	regex :/^[a-zA-Z]+$/
              },
              state: "required",
              district: "required",
               city: "required",
                hname: {
              	required:true,
              	
              },
                 dob: "required",
               
               phone_no: {
                      required: true,
                       minlength: 10,
                       maxlength: 10,
                        regex : /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/
                     
                  },
                     rphone_no: {
                      required: true,
                       minlength: 10,
                       maxlength: 10,
                        regex : /^(?:(?:\+|0{0,2})91(\s*[\-]\s*)?|[0]?)?[789]\d{9}$/
                     
                  },
                  
                  address:
                  {
                  	required: true,
                  },
                   emailid: {
                      required: true,
                     regex :  /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
                     
                  },
                   username: {
                      required: true,
                     regex : /^[A-Za-z0-9]+$/,
                       minlength: 5,
                       maxlength: 15,
                     
                  },
 password: {
                      required: true,
                     regex : /^[A-Za-z0-9]+$/,
                       minlength: 5,
                       maxlength: 15,
                     
                  },
              cpassword: {
                      required: true,
                     regex : /^[A-Za-z0-9]+$/,
                       minlength: 5,
                       maxlength: 15,
                     equalTo: "#password"
                  },

              },
              messages: {
              fname: "Please Enter First Name",
             lname: "Please Enter Last Name",
              state: "Please choose state",
               district: "Please choose District",
                city: "Please choose city",

                 phone_no: "Please Enter Valid 10 digit Phone Number - Starting from 7 or 8 or 9",
                  rphone_no: "Please Enter Valid 10 digit Relative's Phone Number - Starting from 7 or 8 or 9",
               
                   emailid: "Please Enter Valid Email Id",
                   username: "Please Enter Valid User Name(5-15 digit alphanumeric username",
                    password: "Please Enter Valid User Name(5-15 digit alphanumeric password",
                       cpassword: "Please Enter Valid User Name(5-15 digit alphanumeric confirm password and same as above password",
              },
              submitHandler: function (form) {
              form.submit();
              }
          });
        }
      }
  //when the dom has loaded setup form validation rules
  $(D).ready(function ($) {
      JQUERY4U.UTIL.setupFormValidation();
  });
  })(jQuery, window, document);
</script>

						</div>
					</div>
						</div>
					<!-- start content_slider -->
				
				</div>
					<!--//sreen-gallery-cursual---->
			</div>
		</div>
		
		<div class="col_1">
			<div class="col-md-4 span_8">
				
					
			</div>
			<div class="col-md-4 span_8">
				
			</div>
			<div class="col-md-4 span_8">
				
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
			
		</div>
				
			</div>
		</div>
	<!--footer-->
	<div class="footer">
	   <p> All Rights Reserved | Design by <a href="index.php" target="_blank">Rescue Guard</a></p>		
	</div>
    <!--//footer-->
	</div>
		
	<!-- new added graphs chart js-->
	
    
	<!-- //for index page weekly sales java script -->
	
	
	<!-- Bootstrap Core JavaScript -->
   <script src="js/bootstrap.js"> </script>
	<!-- //Bootstrap Core JavaScript -->
	
</body>
</html>