<?php 
//Code to start session
session_start();

$username=$_POST["username"];
//code to encrypt password 
$password=md5($_POST["password"]);
//Include dboperation class file 
 include_once("dbconnection.php");
  // code to create object of class dboperations
       $db=new dbconnection();
    $sql="select count(*) as c, login_id,username,usertype,status from tbl_login where username='$username' and password='$password'";

        $res=$db->execute_query($sql);
        $c=0;
        $logid=0;
        $uname="";
        $utype="";
        $name="";
//Code to fetch database value
        while($row=mysqli_fetch_array($res))
        {
        	$c=$row["c"];
         	$logid=$row["login_id"];
        	$uname=$row["username"];
        	 $utype=$row["usertype"];
            $status=$row["status"];
               
        }

    //----Set session-----------//

       

$_SESSION["slogid"]=$logid;
$_SESSION["suname"]=$uname;




        //-------------------------------------------------------------------------------------------//

        if($c>0)
        {
           
if($status=="Approved")
{
if($utype=="Admin")
{
   
header("location:Admin/disaster_warning_list.php");
}
else if($utype=="User")
{
     

header("location:User/index.php");
}
else if($utype=="Camp")
{
 $sql6="select * from  tbl_camp_status inner join tbl_camp on tbl_camp.login_id = tbl_camp_status.camp_login_id   where tbl_camp_status.camp_login_id='$logid' and tbl_camp.status='Working' and tbl_camp_status.ending_date='0000-00-00'";
       $res6=$db->execute_query($sql6); 
     
       
if(mysqli_num_rows($res6)>0)
{   

header("location:Camp/requirements_list.php");
}
else
{
   ?>
                <script type="">
                    alert("Camp Has  Not been Activated.. Please inform Administrator");
                    window.location="login.php";

                </script>
            <?php    
}
}

else if($utype=="Sponser")
{
     

header("location:Sponser/camp.php");
}


else
{
?>
            	<script type="">
            		alert("Invalid User");
            		window.location="login.php";

            	</script>
            <?php 	
}
}
else if($status=="Rejected")
{
    ?>
                <script type="">
                    alert("Rejected");
                    window.location="login.php";

                </script>
            <?php  
}
else
{
  ?>
                <script type="">
                    alert("Waiting For Approval");
                    window.location="login.php";

                </script>
            <?php   
}
        }
        else
        {
        	?>
            	<script type="">
            alert("Invalid User");
            		window.location="login.php";

            	</script>
            <?php 
        }
?>