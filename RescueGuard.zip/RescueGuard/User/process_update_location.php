<?php

session_start();
$loginid=$_SESSION["slogid"];
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();


$longitude=$_POST['longitude'];
$latitude=$_POST['latitude'];


$sql="select * from tbl_user_position where user_login_id='$loginid'";

        $res=$db->execute_query($sql);
       $c=mysqli_num_rows($res);
  if($c==0)
  {

$sql1="insert into tbl_user_position(user_login_id,longitude,latitude)values('$loginid','$longitude','$latitude')";
}
else
{
	$sql1="Update tbl_user_position set user_login_id='$loginid', longitude='$longitude', latitude='$latitude', 	entry_date =NOW() where user_login_id='$loginid'";
}



$res=$db->execute_query($sql1);


if($res)
{
?>
              <script type="">
                alert("Updated Successfully");
              window.location="disaster_warning.php";

              </script> 
     <?php
 }

?>

