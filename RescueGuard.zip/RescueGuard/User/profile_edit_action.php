<?php
session_start();
$login_id=$_POST["login_id"];
$fname=$_POST["fname"];
$lname=$_POST["lname"];
$gender=$_POST["gender"];
$email=$_POST["email_id"];
$dob=$_POST["date_of_birth"];

$phno=$_POST["phone_number"];
$address=$_POST["home_name"];



//Include dboperation class file 
 include_once("../dbconnection.php");
 // code to create object of class dboperations
       $db=new dbconnection();


     
         $sql2="update  tbl_user_registration set  firstname='$fname', lastname='$lname', gender='$gender', email_id='$email', phone_number='$phno', house_name='$address' ,date_of_birth='$dob' where login_id='$login_id'";
        $res1=$db->execute_query($sql2);
 
            if($res1)
            {
              ?>
              <script type="">
                alert("Profile updated Successfully");
              window.location="profile_edit.php";

              </script>
            <?php 
        }
        ?>





