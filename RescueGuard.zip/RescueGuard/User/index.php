<?php session_start(); ?>
<!DOCTYPE HTML>
<html>
<head>
<title>Rescue Guard</title>

<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Glance Design Dashboard Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
SmartPhone Compatible web template, free WebDesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!--new slide-->
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">


<!-- Bootstrap Core CSS -->
<link href="../css/bootstrap.css" rel='stylesheet' type='text/css' />

<!-- Custom CSS -->
<link href="../css/style.css" rel='stylesheet' type='text/css' />

<!-- font-awesome icons CSS -->
<link href="../css/font-awesome.css" rel="stylesheet"> 
<!-- //font-awesome icons CSS-->

<!-- side nav css file -->
<link href='../css/SidebarNav.min.css' media='all' rel='stylesheet' type='text/css'/>
<!-- //side nav css file -->
 
 <!-- js-->
<script src="../js/jquery-1.11.1.min.js"></script>
<script src="../js/modernizr.custom.js"></script>

<!--webfonts-->
<link href="//fonts.googleapis.com/css?family=PT+Sans:400,400i,700,700i&amp;subset=cyrillic,cyrillic-ext,latin-ext" rel="stylesheet">
<!--//webfonts--> 

<!-- chart -->
<script src="../js/Chart.js"></script>
<!-- //chart -->

<!-- Metis Menu -->
<script src="../js/metisMenu.min.js"></script>
<script src="../js/custom.js"></script>
<link href="../css/custom.css" rel="stylesheet">
<!--//Metis Menu -->
<style>
#chartdiv {
  width: 100%;
  height: 295px;
}

.mySlides {display:none;}
.city {display:none}

</style>
<!--pie-chart --><!-- index page sales reviews visitors pie chart -->
<script src="../js/pie-chart.js" type="text/javascript"></script>
 <script type="text/javascript">

        $(document).ready(function () {
            $('#demo-pie-1').pieChart({
                barColor: '#2dde98',
                trackColor: '#eee',
                lineCap: 'round',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-2').pieChart({
                barColor: '#8e43e7',
                trackColor: '#eee',
                lineCap: 'butt',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

            $('#demo-pie-3').pieChart({
                barColor: '#ffc168',
                trackColor: '#eee',
                lineCap: 'square',
                lineWidth: 8,
                onStep: function (from, to, percent) {
                    $(this.element).find('.pie-value').text(Math.round(percent) + '%');
                }
            });

           
        });

    </script>
<!-- //pie-chart --><!-- index page sales reviews visitors pie chart -->

	<!-- requried-jsfiles-for owl -->
					<link href="../css/owl.carousel.css" rel="stylesheet">
					<script src="../js/owl.carousel.js"></script>
						<script>
							$(document).ready(function() {
								$("#owl-demo").owlCarousel({
									items : 3,
									lazyLoad : true,
									autoPlay : true,
									pagination : true,
									nav:true,
								});
							});
						</script>
					<!-- //requried-jsfiles-for owl -->


					
</head> 
<body class="cbp-spmenu-push">
	<?php
if(isset($_SESSION["slogid"]))
{
	?>
	<div class="main-content">
	<div class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="cbp-spmenu-s1">
		<!--left-fixed -navigation-->
		<aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">

          	<h1><a class="navbar-brand" href="login.php"><span><img src="../images/r.png" style="width:80%"></a></h1>
            <!--<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>-->

            
          </div>
          <br>
            <br>
            <br>
            <br>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="sidebar-menu">
              <li class="header"> </li>
              <li class="treeview active">
                <a href="index.php">
                <i class="fa fa-dashboard"></i> <span>Home</span>
                </a>
              </li>
              <li class="treeview">
                <a href="Profile_edit.php">
                <i class="fa fa-user"></i> <span>Profile Edit</span>
                </a>
              </li>

			 <li class="treeview">
                <a href="disaster_warning.php">
                <i class="fa fa-sign-in"></i> <span>Disaster Warning</span>
                </a>
              </li>
             
              <li class="treeview">
                <a href="camp.php">
                <i class="fa fa-user"></i> <span>Camp Details</span>
                </a>
              </li>
               <li class="treeview ">
                <a href="#">
                <i class="fa fa-folder"></i> <span>Information</span>
                <i class="fa fa-angle-left pull-right"></i>
                </a>
                 <ul class="treeview-menu">
                 
                    <li><a href="bank_branches.php"><i class="fa fa-angle-right"></i> Bank Branches</a></li>
                  <li><a href="atm.php"><i class="fa fa-angle-right"></i> ATM</a></li>
                  <li><a href="hospital.php"><i class="fa fa-angle-right"></i> Hospital</a></li>
                  <li><a href="police_station.php"><i class="fa fa-angle-right"></i> Police Station</a></li>
                </ul>
              </li>
              <li class="treeview">
                <a href="complaint.php">
                <i class="fa fa-user"></i> <span>Complaints</span>
                </a>
              </li>
             <li class="treeview">
                <a href="change_password.php">
                <i class="fa fa-user"></i> <span>Change Password</span>
                </a>
              </li>
               <li class="treeview">
                <a href="../logout.php">
                <i class="fa fa-sign-out"></i> <span>Log Out</span>
                </a>
              </li>
            </ul>
          </div>
          <!-- /.navbar-collapse -->
      </nav>
    </aside>
	</div>
		<!--left-fixed -navigation-->
		
		<!-- header-starts -->
		<div class="sticky-header header-section ">
			<div class="header-left">
				<!--toggle button start-->
				
				<!--toggle button end-->
				<div class="profile_details_left"><!--notifications of menu start -->
		
					<div class="clearfix"> </div>
				</div>
				<!--notification menu end -->
				<div class="clearfix"> </div>
			</div>
			<div class="header-right">
				
				
		
				
				<div class="profile_details">		
					<ul>
						<li class="dropdown profile_details_drop">
							<a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
								<div class="profile_img">	
									<span class="prfil-img"><img src="../images/p1.jpg" alt=""> </span> 
									<div class="user-name">
										<p>User</p>
										<span><?php echo  $_SESSION["suname"]?></span>
									</div>
									<i class="fa fa-angle-down lnr"></i>
									<i class="fa fa-angle-up lnr"></i>
									<div class="clearfix"></div>	
								</div>	
							</a>
							<ul class="dropdown-menu drp-mnu">
								<li> <a href="index.php"><i class="fa fa-cog"></i> Home</a> </li> 
								
				<li> <a href="disaster_warning.php">
                <i class="fa fa-user"></i> <span>Disaster Warning</span>
                </a> </li> 
							<li><a href="camp.php">
                <i class="fa fa-user"></i> <span>Camp Details</span>
                </a></li>
                 <li >
                <a href="change_password.php">
                <i class="fa fa-user"></i> <span>Change Password</span>
                </a>
              </li>
              <li>
                <a href="../logout.php">
                <i class="fa fa-sign-out"></i> <span>Log Out</span>
                </a></li>
						</li>
					</ul>
				</div>
				<div class="clearfix"> </div>				
			</div>
			<div class="clearfix"> </div>	
		</div>
		<!-- //header-ends -->
		<!-- main content start-->
		<div id="page-wrapper">
			<div class="main-page">
			<div class="col_3">
        	
        	<div class="clearfix"> </div>
		</div>
		
	

				
	
	<!-- for amcharts js -->
			<script src="../js/amcharts.js"></script>
			<script src="../js/serial.js"></script>
			<script src="../js/export.min.js"></script>
			<link rel="stylesheet" href="../css/export.css" type="text/css" media="all" />
			<script src="../js/light.js"></script>
	<!-- for amcharts js -->

    <script  src="../js/index1.js"></script>






	
		<div class="charts">		
			<div class="mid-content-top charts-grids">
				<div class="middle-content">
						<h4 class="title" align="Center">What do you mean by Disaster?</h4>
						<div style="text-align: justify; ">


						 <!--<img src="dis1.jpg" alt="Cinque Terre" width="900" height="900">-->
						</div>
					<!-- start content_slider -->
				
				</div>
					<!--//sreen-gallery-cursual---->
			</div>
		</div>


 







		<div class="charts">		
			<div class="mid-content-top charts-grids">
				<div class="middle-content">
						<h2 class="title"></h2>
						<br>
						<br>
						<div style="text-align: justify; ">
<div class="w3-content w3-section" style="max-width:500px">
  <img class="mySlides w3-animate-top" src="img/download5.jpg" style="width:130%">
  <img class="mySlides w3-animate-bottom" src="img/download7.jpg" style="width:130%">
  <img class="mySlides w3-animate-top" src="img/download6.jpg" style="width:130%">
  <img class="mySlides w3-animate-bottom" src="img/download9.jpg" style="width:130%">

<img class="mySlides w3-animate-bottom" src="img/b.jpg" style="width:130%">
<img class="mySlides w3-animate-bottom" src="img/e.jpg" style="width:130%">
<img class="mySlides w3-animate-bottom" src="img/e1.jpg" style="width:130%">

</div>
</div>
</div>

<script>
var myIndex = 0;
carousel();

function carousel() {
  var i;
  var x = document.getElementsByClassName("mySlides");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";  
  }
  myIndex++;
  if (myIndex > x.length) {myIndex = 1}    
  x[myIndex-1].style.display = "block";  
  setTimeout(carousel, 2500);    
}
</script>


            <br>
            <br>
           



							
						<p>	A disaster is a serious disruption occurring over a short or long period of time that causes widespread human, material, economic or environmental loss which exceeds the ability of the affected community or society to cope using its own resources.Developing countries suffer the greatest costs when a disaster hits – more than 95 percent of all deaths caused by hazards occur in developing countries, and losses due to natural hazards are 20 times greater (as a percentage of GDP) in developing countries than in industrialized countries.
</p>
<br>
<br>

<p>

	<h3>Natural Disasters</h3>
	<br>


A natural disaster is a natural process or phenomenon that may cause loss of life, injury or other health impacts, property damage, loss of livelihoods and services, social and economic disruption, or environmental damage.

Various phenomena like earthquakes, landslides, volcanic eruptions, floods, hurricanes, tornadoes, blizzards, tsunamis, and cyclones are all natural disasters that kill thousands of people and destroy billions of dollars of habitat and property each year. However, the rapid growth of the world's population and its increased concentration often in hazardous environments has escalated both the frequency and severity of disasters. With the tropical climate and unstable landforms, coupled with deforestation, unplanned growth proliferation, non-engineered constructions make the disaster-prone areas more vulnerable. Developing countries suffer more or less chronically from natural disasters due to ineffective communication combined with insufficient budgetary allocation for disaster prevention and management.


Airplane crashes and terrorist attacks are examples of man-made disasters: they cause pollution, kill people, and damage property. This example is of the September 11 attacks in 2001 at the World Trade Center in New York.

<br>
<br>
<h3>Human-made disasters</h3>
<br>

Human-instigated disasters are the consequence of technological or human hazards. Examples include stampedes, fires, transport accidents, industrial accidents, oil spills, nuclear explosions/nuclear radiation. War and deliberate attacks may also be put in this category.

Other types of induced disasters include the more cosmic scenarios of catastrophic global warming, nuclear war, and bioterrorism.

One opinion argues that disasters can be seen as human-made, due to human failure to introduce appropriate emergency management measures.


	</p>
<p>Tools used might include search and rescue dogs, mounted search and rescue horses, helicopters, the "jaws of life", and other hydraulic cutting and spreading tools used to extricate individuals from wrecked vehicles. Rescue operations are sometimes supported by special vehicles such as fire department's or EMS heavy rescue vehicle.</p> 
<p>Rescue operations require a high degree of training and are performed by rescue squads, either independent or part of larger organizations such as fire, police, military, first aid, or ambulance services.</p>

<br>
<br>

<div class="w3-container">

<center>
<button onclick="document.getElementById('id01').style.display='block'" class="w3-button w3-black">Disaster Types</button></center>

<div id="id01" class="w3-modal">
 <div class="w3-modal-content w3-card-4 w3-animate-zoom">
  <header class="w3-container w3-grey"> 
   <span onclick="document.getElementById('id01').style.display='none'" 
   class="w3-button w3-grey w3-xlarge w3-display-topright">&times;</span>
   <h2><font color="white">Types</font></h2>
  </header>

  <div class="w3-bar w3-border-bottom">
   <button class="tablink w3-bar-item w3-button" onclick="openCity(event, 'Geophysical')"><h2><b>Geophysical</b></h2></button>
   <button class="tablink w3-bar-item w3-button" onclick="openCity(event, 'Hydrological')"><h2><b>Hydrological</b></h2></button>
   <button class="tablink w3-bar-item w3-button" onclick="openCity(event, 'Climatological')"><h2><b>Climatological</b></h2></button>
   <button class="tablink w3-bar-item w3-button" onclick="openCity(event, 'Meteorological')"><h2><b>Meteorological</b></h2> </button>
  </div>
<br>

  <div id="Geophysical" class="w3-container city">
   <h2><u><i>Earthquakes</i></u></h2>
   
   <p>An earthquake is the sudden movement of the Earth's tectonic plates, resulting in shaking of the ground. This shaking can result in the damage of various structures such as buildings and further breakdown of the Earth's surface.any sudden shaking of the ground caused by the passage of seismic waves through Earth’s rocks. Seismic waves are produced when some form of energy stored in Earth’s crust is suddenly released, usually when masses of rock straining against one another suddenly fracture and “slip.” </p><br>

    <h1>Landslides</h1>
   <br>
   <p>A landslide is defined as the movement of a mass of rock, debris, or earth down a slope. Landslides are a type of "mass wasting," which denotes any down-slope movement of soil and rock under the direct influence of gravity. The term "landslide" encompasses five modes of slope movement: falls, topples, slides, spreads, and flows. </p><br>
  
  <h1>Tsunamis</h1><br>
   <p>Tsunamis are ocean waves triggered by large earthquakes that occur near or under the ocean, volcanic eruptions, submarine landslides, and by onshore landslides in which large volumes of debris fall into the water. Scientists do not use the term "tidal wave" because these waves are not caused by tides. Tsunami waves are unlike typical ocean waves generated by wind and storms, and most tsunamis do not "break" like the curling, wind-generated waves popular with surfers. Tsunamis typically consist of multiple waves that rush ashore like a fast-rising tide with powerful currents.</p><br>

   <h1>Volcanic Eruption</h1><br>
   <p> A volcanic eruption occurs when molten rock, ash and steam pour through a vent in the earth's crust.

Volcanoes are described as active (in eruption), dormant (not erupting at the present time), or extinct (having ceased eruption; no longer active). Some volcanoes explode. Others are slow-flowing fountains of lava, which is hot fluid rock.</p><br>

  </div>





<div id="Hydrological" class="w3-container city">
  <h1>Avalanches</h1>
   <br>
   <p>An avalanche is a mass of snow that slides rapidly down an inclined slope, such as a mountainside or the roof of a building. Avalanches are triggered by either natural forces (e.g. precipitation, wind drifting snow, rapid temperature changes) or human activity. In mountainous terrain, they are among the most serious hazards to human life and property. Avalanches are sometimes called snowslides.</p><br>

    <h1>Floods</h1><br>
   <p>It is a natural event or occurrence where a piece of land (or area) that is usually dry land, suddenly gets submerged under water. Some floods can occur suddenly and recede quickly. Others take days or even months to build and discharge.
</p><br>
  </div>

<div id="Climatological" class="w3-container city">
  <h1>Extreme Temperatures</h1>
   <br>
   <p>Extreme Heat. Temperatures that hover 10 degrees or more above the average high temperature for the region and last for several weeks are defined as extreme heat.</p><br>

    <h1>Drought</h1><br>
   <p>Drought is a reduction in precipitation over an extended period. This rain shortfall creates a water shortage which damages crops, livestock, and other human activities. A drought has both direct and indirect impacts. It directly reduces farmers' crops. It indirectly causes job and business losses in the farmers’ communities and around the world.</p><br>

<h1>WildFires</h1><br>
   <p>Wildfires are fires that burn out of control in a natural area, like a forest, grassland, or prairie. They often begin unnoticed. They spread quickly, and can damage natural resources, destroy homes, and threaten the safety of the public and firefighters.</p><br>


  </div>




<div id="Meteorological" class="w3-container city">
  <h1>Cyclones</h1>
   <br>
   <p>A cyclone is a general term for a weather system in which winds rotate inwardly to an area of low atmospheric pressure. For large weather systems, the circulation pattern is in a counterclockwise direction in the Northern Hemisphere and a clockwise direction in the Southern Hemisphere.</p><br>

    <h1>Storms/Wave Surges</h1>
    <br>
   <p>A storm is a powerful disturbance of the atmosphere. Thunderstorms, tornadoes, and hurricanes are types of storms. Storms are a common event here on Earth. They occur on other planets, too.</p><br>
  </div>

  

  <div class="w3-container w3-light-grey w3-padding">
   <button class="w3-button w3-right w3-grey w3-border" 
   onclick="document.getElementById('id01').style.display='none'"><font color="white">Close</font></button>
  </div>
 </div>
</div>

</div>

<script>
document.getElementsByClassName("tablink")[0].click();

function openCity(evt, cityName) {
  var i, x, tablinks;
  x = document.getElementsByClassName("city");
  for (i = 0; i < x.length; i++) {
    x[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < x.length; i++) {
    tablinks[i].classList.remove("w3-light-grey");
  }
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.classList.add("w3-light-grey");
}
</script>

						</div>
					<!-- start content_slider -->
				
				</div>
					<!--//sreen-gallery-cursual---->
			</div>
		</div>






		
		<div class="col_1">
			<div class="col-md-4 span_8">
				
					
			</div>
			<div class="col-md-4 span_8">
				
			</div>
			<div class="col-md-4 span_8">
				
				<div class="clearfix"> </div>
			</div>
			<div class="clearfix"> </div>
			
		</div>
				
			</div>
		</div>
	<!--footer-->
	<div class="footer">
	   <p> All Rights Reserved | Design by <a href="#" target="_blank">Rescue Guard</a></p>		
	</div>
    <!--//footer-->
	</div>
		
	<script src='../js/SidebarNav.min.js' type='text/javascript'></script>
  <script>
      $('.sidebar-menu').SidebarNav()
    </script>
  <!-- //side nav js -->
  
  <!-- Classie --><!-- for toggle left push menu script -->
    <script src="../js/classie.js"></script>
    <script>
      var menuLeft = document.getElementById( 'cbp-spmenu-s1' ),
        showLeftPush = document.getElementById( 'showLeftPush' ),
        body = document.body;
        
      showLeftPush.onclick = function() {
        classie.toggle( this, 'active' );
        classie.toggle( body, 'cbp-spmenu-push-toright' );
        classie.toggle( menuLeft, 'cbp-spmenu-open' );
        disableOther( 'showLeftPush' );
      };
      
      function disableOther( button ) {
        if( button !== 'showLeftPush' ) {
          classie.toggle( showLeftPush, 'disabled' );
        }
      }
    </script>
  <!-- //Classie --><!-- //for toggle left push menu script -->
    
  <!--scrolling js-->
  <script src="../js/jquery.nicescroll.js"></script>
  <script src="../js/scripts.js"></script>
  <!--//scrolling js-->
  
  <!-- Bootstrap Core JavaScript -->
   <script src="../js/bootstrap.js"> </script>
   

  <?php 
}
else
{
  header("Location:../index.php");
}
  ?>

</body>
</html>