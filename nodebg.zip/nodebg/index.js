import http from 'http';
import express from 'express';
import { Server } from 'socket.io';



//const express = require('express');
//const http = require('http');
//const socketIo = new Server('socket.io');

const PORT = process.env.PORT || 4001;

const app = express();    //object for express
app.use(express.static('public'));

const server = http.createServer(app);      //toCreateServer..
const io =new Server(server);

//mapping userid,sessid,etc..
const userSockets = new Map();

//SocketEventListener
io.on('connection', (socket) => {     //socket here is var..
  console.log(`Client connected; ${socket.id}`);


  socket.on('sendLocation', (data) => {   //sendloc is eventName and data is the dataSentFromMobile;callingFunc..

    console.log('Received location:', data);
    io.emit('changeLocation', data);
  });

//executes when the socket gets disconnected..
  socket.on('disconnect', () => {
    for (let [uid,skid] of userSockets.entries()) {
      if (skid==socket.id) {
        userSockets.delete(uid);
        break;
      }      
    }
    console.log('Client disconnected');
  });

  //executesforJoinSessevenet..
  socket.on('user-join', (data) => {   //user-join is eventName and data is the dataSentFromMobile;callingFunc..
    userSockets.set(data, socket.id);  //data is emitedfromSenderToHere,Then loaded..
    console.log(userSockets);
    io.to(socket.id).emit('session-join','urSessionJoined.frmNode.'); //otherDatIsSend from here to Receiver..of eventSessionjoin..
  });
    //data can be username..
});


app.use(express.json());
//app.get('api/logout',)
app.get('/api/logout',(req,res) => {
  const usrid = req.query.userId;
  if (!usrid) {
    return res.status(400).json({success:false, message:'useridReqrd..'});
  }
  //else,ifUsrId has been received,go down..
  console.log(userSockets);
  const soktId = userSockets.get(usrid);
  if (soktId) {
    io.to(soktId).emit('session-expired','uR=rSessionExpires/terminated..');
    console.log(soktId);
    return res.status(200).json({success:true, message:'loggedOut;;;;'});    
  }
  else
  return res.status(400).json({success:false, message:'NoActiveSessn..'});
});



server.listen(PORT, () => console.log(`Listening on port ${PORT}`));
//app.get('/', (req,res) => {
//res.sendFile(__dirname+'/index.html');
//});
