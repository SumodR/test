// server.js
import http from 'http';
import express from 'express';
import { Server } from 'socket.io';
import cors from 'cors';
import bodyParser from 'body-parser';
import sqlite3 from 'sqlite3';
import bcrypt from 'bcrypt';

const app = express();
const server = http.createServer(app);
const io =new Server(server);

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Database setup
const db = new sqlite3.Database('./mydatabase.db');

// Start server
const PORT = process.env.PORT || 4001;
server.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});


    // ====  User Registration  ====
app.post('/register', (req, res) => {
    const { username, password, role, profile_info } = req.body;
    const hashedPassword = password; // Replace with actual hashing (e.g., bcrypt)
    
    db.run(`INSERT INTO users (username, password, role, profile_info) VALUES (?, ?, ?, ?)`, 
        [username, hashedPassword, role, profile_info], 
        function(err) {
            if (err) {
                return res.status(400).json({ error: err.message });
            }
            res.status(201).json({ id: this.lastID });
        });
});


    // ==== User Login  ====
app.post('/login', (req, res) => {
    const { username, password } = req.body;

    db.get(`SELECT * FROM users WHERE username = ?`, [username], (err, user) => {
        if (err || !user) {
            return res.status(400).json({ error: 'User not found' });
        }

        // Compare hashed password (assuming you store hashed passwords)
        if (user.password !== password) { // Replace with bcrypt.compare
            return res.status(400).json({ error: 'Invalid password' });
        }

        res.json({ message: 'Login successful', user });
    });
});



    // ======   Socket.IO connection    ======
io.on('connection', (socket) => {
    console.log('A user connected');

    socket.on('driverLocation', (data) => {
        const { driver_id, latitude, longitude } = data;

        db.run(`INSERT INTO driver_locations (driver_id, latitude, longitude) VALUES (?, ?, ?)`, 
            [driver_id, latitude, longitude], 
            function(err) {
                if (err) {
                    console.error(err.message);
                }
                // Broadcast to all connected clients
                io.emit('updateLocation', { driver_id, latitude, longitude });
            });
    });

    socket.on('disconnect', () => {
        console.log('User disconnected');
    });
});
